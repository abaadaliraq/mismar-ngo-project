export const messages = {
  "m001": {
    "en": "ABU NAWAS\nHERITAGE REVITALIZATION PROJECT",
    "ar": "مشروع إحياء شارع أبو نؤاس التراثي"
  },
  "m002": {
    "en": "Safeguarding, Restoration & Adaptive Reuse\nof Historic Houses in Baghdad",
    "ar": "حماية وترميم وتأهيل البيوت التراثية\nوإعادة توظيفها في بغداد"
  },
  "m003": {
    "en": "Baghdad — Abu Nawas",
    "ar": "بغداد — أبو نؤاس"
  },
  "m004": {
    "en": "Project Location and Access Routes",
    "ar": "موقع المشروع ومحاور الوصول"
  },
  "m005": {
    "en": "An illustrative map showing the project location and its relationship to surrounding transport and access routes.",
    "ar": "خريطة توضيحية لموقع المشروع وعلاقته بمحاور الحركة والوصول المحيطة."
  },
  "m006": {
    "en": "02 — The Opportunity",
    "ar": "02 — الفرصة"
  },
  "m007": {
    "en": "A Strategic Location with Untapped Heritage Value",
    "ar": "موقع استراتيجي وقيمة تراثية غير مستثمرة"
  },
  "m008": {
    "en": "The street connects Abu Nawas and Al-Saadoon, close to the new Corniche and a cluster of hotels, giving it real potential to become an active heritage and tourism destination. Visual neglect and inadequate services currently obscure its architectural and investment value.",
    "ar": "يربط الشارع بين أبو نؤاس والسعدون، ويقع بالقرب من الكورنيش الجديد ومجموعة من الفنادق، ما يمنحه مقومات حقيقية للتحول إلى وجهة تراثية وسياحية نشطة. إلا أن الإهمال البصري والخدمي يحجب حالياً قيمته العمرانية والاستثمارية."
  },
  "m009": {
    "en": "Houses within the project area",
    "ar": "بيتاً ضمن نطاق المشروع"
  },
  "m010": {
    "en": "100–250 m²",
    "ar": "100–250 م²"
  },
  "m011": {
    "en": "Estimated area per house",
    "ar": "المساحة التقديرية للبيت الواحد"
  },
  "m012": {
    "en": "A pivotal location",
    "ar": "موقع محوري"
  },
  "m013": {
    "en": "Connecting Abu Nawas and Al-Saadoon",
    "ar": "يربط أبو نؤاس بالسعدون"
  },
  "m014": {
    "en": "An established visitor attraction",
    "ar": "جذب سياحي قائم"
  },
  "m015": {
    "en": "House of Antiques Museum",
    "ar": "متحف بيت التحفيات"
  },
  "m016": {
    "en": "An investment opportunity",
    "ar": "فرصة استثمارية"
  },
  "m017": {
    "en": "Heritage assets suitable for adaptive reuse",
    "ar": "أصول تراثية قابلة لإعادة التوظيف"
  },
  "m018": {
    "en": "03 — Strategic Location",
    "ar": "03 — الموقع الاستراتيجي"
  },
  "m019": {
    "en": "A Strategic Location between Abu Nawas and Al-Saadoon",
    "ar": "موقع استراتيجي بين أبو نؤاس والسعدون"
  },
  "m020": {
    "en": "The project within central Baghdad’s tourism network",
    "ar": "موقع المشروع ضمن النسيج السياحي لوسط بغداد"
  },
  "m021": {
    "en": "The project lies along a link between Abu Nawas Street and Al-Saadoon Street, opposite the entrance and exit gate of the new Corniche. Its proximity to hotels and established attractions gives it real potential to become an active heritage and tourism destination.",
    "ar": "يقع المشروع ضمن محور رابط بين شارع أبو نؤاس وشارع السعدون، مقابل بوابة الدخول والخروج من الكورنيش الجديد، وعلى مقربة من مجموعة من الفنادق ونقاط الجذب السياحي القائمة، مما يمنحه قابلية حقيقية للتحول إلى وجهة تراثية وسياحية نشطة."
  },
  "m022": {
    "en": "The Project’s Strategic Location",
    "ar": "الموقع الاستراتيجي للمشروع"
  },
  "m023": {
    "en": "A link between Abu Nawas Street and Al-Saadoon Street",
    "ar": "محور رابط بين شارع أبو نؤاس وشارع السعدون"
  },
  "m024": {
    "en": "04 — Current Street Conditions",
    "ar": "04 — حالة الشارع الحالية"
  },
  "m025": {
    "en": "Current Street Conditions",
    "ar": "حالة الشارع الحالية"
  },
  "m026": {
    "en": "A visual record of the street, heritage houses, encroachments, wiring and service infrastructure before rehabilitation begins.",
    "ar": "توثيق بصري لحالة الشارع والبيوت التراثية والتجاوزات والأسلاك والبنية الخدمية قبل بدء أعمال التأهيل."
  },
  "m027": {
    "en": "Target Properties and Areas within the Project Boundary",
    "ar": "العقارات والمساحات المستهدفة ضمن نطاق المشروع"
  },
  "m028": {
    "en": "An illustrative map of the target properties and areas within the project boundary.",
    "ar": "خريطة توضيحية للعقارات والمساحات المستهدفة ضمن نطاق المشروع."
  },
  "m029": {
    "en": "05 — Preliminary Rehabilitation Vision",
    "ar": "05 — الرؤية المبدئية بعد التأهيل"
  },
  "m030": {
    "en": "Preliminary Rehabilitation Vision",
    "ar": "الرؤية المبدئية بعد التأهيل"
  },
  "m031": {
    "en": "An initial concept for the street’s potential following the removal of encroachments, infrastructure improvements, facade restoration, and the introduction of lighting, planting and a unified identity.",
    "ar": "تصور أولي لإمكانات الشارع بعد معالجة التجاوزات والبنية التحتية وترميم الواجهات وإضافة الإنارة والتشجير والهوية الموحدة."
  },
  "m032": {
    "en": "06 — Existing Conditions",
    "ar": "06 — الواقع الحالي"
  },
  "m033": {
    "en": "Architectural Value Obscured by Visual Clutter",
    "ar": "قيمة معمارية محاصرة بالفوضى البصرية"
  },
  "m034": {
    "en": "Tangled and exposed wiring.",
    "ar": "أسلاك متشابكة ومكشوفة."
  },
  "m035": {
    "en": "Encroachments that obstruct facades and circulation routes.",
    "ar": "تجاوزات تشوه الواجهات ومسار الحركة."
  },
  "m036": {
    "en": "Inconsistent pavements and paving.",
    "ar": "أرصفة وتبليط غير متجانسين."
  },
  "m037": {
    "en": "Facades without a coordinated treatment.",
    "ar": "واجهات بلا معالجة موحدة."
  },
  "m038": {
    "en": "Inadequate lighting and planting.",
    "ar": "ضعف الإنارة والتشجير."
  },
  "m039": {
    "en": "A lack of visitor wayfinding and a distinct sense of place.",
    "ar": "غياب الإرشاد السياحي والهوية المكانية."
  },
  "m040": {
    "en": "07 — Existing Assets",
    "ar": "07 — الأصل القابل للبناء"
  },
  "m041": {
    "en": "Building on an Established Foundation",
    "ar": "المشروع لا يبدأ من الصفر"
  },
  "m042": {
    "en": "The street already has heritage buildings and connections to hospitality and tourism routes. It also hosts the House of Antiques Museum, a museum and shop specializing in antiques and heritage collections that has attracted tourists, artists and art and heritage enthusiasts for decades.",
    "ar": "يمتلك الشارع مباني تراثية قائمة، وموقعاً متصلاً بمحاور الضيافة والسياحة، إضافة إلى وجود متحف بيت التحفيات داخل الشارع، وهو متحف ومتجر متخصص بالأنتيك والمقتنيات التراثية، ويستقطب منذ عقود السياح والفنانين والمهتمين بالفن والتراث."
  },
  "m043": {
    "en": "08 — Proposed Vision",
    "ar": "08 — الرؤية المقترحة"
  },
  "m044": {
    "en": "From a Neglected Street to a Productive Heritage District",
    "ar": "من شارع مهمل إلى منطقة تراثية منتجة"
  },
  "m045": {
    "en": "Conservation",
    "ar": "الحفظ"
  },
  "m046": {
    "en": "Restoring houses and original architectural features.",
    "ar": "ترميم البيوت والعناصر المعمارية الأصلية."
  },
  "m047": {
    "en": "Operation",
    "ar": "التشغيل"
  },
  "m048": {
    "en": "Adapting buildings for cultural, tourism and hospitality enterprises.",
    "ar": "تحويل المباني إلى مشاريع ثقافية وسياحية وضيافة."
  },
  "m049": {
    "en": "Returns",
    "ar": "العائد"
  },
  "m050": {
    "en": "Generating direct and indirect revenue, jobs and local economic activity.",
    "ar": "خلق إيرادات مباشرة وغير مباشرة وفرص عمل ونشاط اقتصادي محلي."
  },
  "m051": {
    "en": "09 — Urban Rehabilitation Scope",
    "ar": "09 — نطاق التأهيل الحضري"
  },
  "m052": {
    "en": "Coordinated Urban Improvements before Commercial Operation",
    "ar": "تدخل حضري منظم قبل التشغيل التجاري"
  },
  "m053": {
    "en": "Removing encroachments and organizing facades.",
    "ar": "رفع التجاوزات وتنظيم الواجهات."
  },
  "m054": {
    "en": "Upgrading and relocating electricity and telecommunications networks safely and systematically.",
    "ar": "معالجة ونقل شبكات الكهرباء والاتصالات بطريقة نظامية وآمنة."
  },
  "m055": {
    "en": "Street cleaning and waste management.",
    "ar": "تنظيف الشارع وإدارة المخلفات."
  },
  "m056": {
    "en": "Repaving the street and pavements.",
    "ar": "إعادة تبليط الشارع والأرصفة."
  },
  "m057": {
    "en": "Restoring and repainting facades in accordance with unified guidelines.",
    "ar": "ترميم وصبغ الواجهات وفق دليل موحد."
  },
  "m058": {
    "en": "Architectural lighting, planting, street furniture and bilingual signage.",
    "ar": "إنارة معمارية، تشجير، أثاث حضري، ولوحات ثنائية اللغة."
  },
  "m059": {
    "en": "Organizing vehicle movement, service parking and safety systems.",
    "ar": "تنظيم حركة المركبات ومواقف الخدمة وأنظمة السلامة."
  },
  "m060": {
    "en": "Restoration will follow specialist architectural and structural documentation.",
    "ar": "تنفذ أعمال الترميم بعد توثيق معماري وإنشائي متخصص."
  },
  "m061": {
    "en": "10 — Adaptive Reuse of the Sixteen Houses",
    "ar": "10 — إعادة توظيف البيوت الستة عشر"
  },
  "m062": {
    "en": "A Diverse Mix of Uses That Creates a Distinct Destination",
    "ar": "مزيج أنشطة يصنع وجهة لا نسخة مكررة"
  },
  "m063": {
    "en": "A heritage boutique hotel",
    "ar": "فندق بوتيك تراثي"
  },
  "m064": {
    "en": "Baghdadi guesthouses",
    "ar": "بيوت ضيافة بغدادية"
  },
  "m065": {
    "en": "A contemporary Iraqi restaurant",
    "ar": "مطعم عراقي معاصر"
  },
  "m066": {
    "en": "A cultural café",
    "ar": "مقهى ثقافي"
  },
  "m067": {
    "en": "An art gallery",
    "ar": "معرض فنون"
  },
  "m068": {
    "en": "A museum of Baghdadi memory",
    "ar": "متحف للذاكرة البغدادية"
  },
  "m069": {
    "en": "A traditional crafts centre",
    "ar": "مركز للحرف التقليدية"
  },
  "m070": {
    "en": "Antique and collectible shops",
    "ar": "متاجر أنتيك ومقتنيات"
  },
  "m071": {
    "en": "Artists’ studios and workshops",
    "ar": "استوديوهات ومراسم للفنانين"
  },
  "m072": {
    "en": "A venue for music and evening events",
    "ar": "مساحة عروض موسيقية وأمسيات"
  },
  "m073": {
    "en": "A library and shop for books and historical photographs",
    "ar": "مكتبة ومتجر كتب وصور تاريخية"
  },
  "m074": {
    "en": "An Iraqi culinary experience centre",
    "ar": "مركز تجارب طبخ عراقي"
  },
  "m075": {
    "en": "A house of Iraqi fashion and crafts",
    "ar": "بيت للأزياء والحرف العراقية"
  },
  "m076": {
    "en": "A visitor and tourism information centre",
    "ar": "مركز للزوار والمعلومات السياحية"
  },
  "m077": {
    "en": "A temporary exhibition space",
    "ar": "مساحة للمعارض المؤقتة"
  },
  "m078": {
    "en": "A cultural industries incubator",
    "ar": "حاضنة للصناعات الثقافية"
  },
  "m079": {
    "en": "The final use of each property will depend on its structural condition, area and investment feasibility, while avoiding duplication of activities.",
    "ar": "التخصيص النهائي لكل عقار يعتمد على حالته الإنشائية ومساحته والجدوى الاستثمارية ومنع تكرار الأنشطة."
  },
  "m080": {
    "en": "11 — Women’s Empowerment",
    "ar": "11 — تمكين المرأة"
  },
  "m081": {
    "en": "Women as Partners in the Heritage Economy",
    "ar": "المرأة شريك في تشغيل الاقتصاد التراثي"
  },
  "m082": {
    "en": "An economic programme supporting women’s participation in cultural and creative industries",
    "ar": "برنامج اقتصادي لدعم مشاركة المرأة في الصناعات الثقافية والإبداعية"
  },
  "m083": {
    "en": "The project includes a pathway for women’s economic empowerment by involving women-led businesses, craftswomen, artists and female tour guides in cultural and commercial operations. It will work with specialist institutions or a sponsor, using clear indicators for jobs, sales and business sustainability.",
    "ar": "يخصص المشروع مساراً لتمكين المرأة اقتصادياً من خلال إشراك المشاريع النسائية والحرفيات والفنانات والمرشدات السياحيات في تشغيل الأنشطة الثقافية والتجارية، بالتعاون مع مؤسسات متخصصة أو جهة راعية، وبمؤشرات واضحة لفرص العمل والمبيعات واستدامة المشاريع."
  },
  "m084": {
    "en": "12 — Revenue Model",
    "ar": "12 — نموذج الإيرادات"
  },
  "m085": {
    "en": "How Can the Project Generate Sustainable Revenue?",
    "ar": "كيف يحقق المشروع إيرادات مستدامة؟"
  },
  "m086": {
    "en": "Transforming neglected heritage buildings into a productive tourism and investment ecosystem",
    "ar": "تحويل الأصول التراثية من مبانٍ مهملة إلى منظومة سياحية واستثمارية منتجة"
  },
  "m087": {
    "en": "13 — Financial Simulation",
    "ar": "13 — محاكاة مالية"
  },
  "m088": {
    "en": "Revenue and Financial Return Simulation",
    "ar": "محاكاة الإيرادات والعائد المالي"
  },
  "m089": {
    "en": "A preliminary tool for assessing scenarios before property valuation and a detailed feasibility study are completed",
    "ar": "أداة أولية لقياس السيناريوهات قبل استكمال التقييم العقاري ودراسة الجدوى التفصيلية"
  },
  "m090": {
    "en": "14 — Potential for Expansion",
    "ar": "14 — قابلية التوسع"
  },
  "m091": {
    "en": "From a Pilot Project to an Integrated Heritage District",
    "ar": "من مشروع تجريبي إلى منطقة تراثية متكاملة"
  },
  "m092": {
    "en": "The street is the first phase of an urban and investment model that could expand into surrounding side streets, which also contain heritage houses and neglected buildings. Success in the first phase could establish an interconnected network of cultural and tourism routes beyond the rehabilitation of a single street.",
    "ar": "يمثل الشارع المرحلة الأولى لنموذج حضري واستثماري قابل للتوسع نحو الفروع المحيطة، التي تضم بدورها عدداً من البيوت التراثية والمباني المهملة. ويتيح نجاح المرحلة الأولى إنشاء شبكة مترابطة من المسارات الثقافية والسياحية بدلاً من الاكتفاء بتأهيل شارع منفرد."
  },
  "m093": {
    "en": "15 — Ownership and Investment Model",
    "ar": "15 — نموذج التملك والاستثمار"
  },
  "m094": {
    "en": "A Hybrid Model to Reduce Upfront Costs and Accelerate Operation",
    "ar": "نموذج هجين يقلل كلفة البداية ويسرّع التشغيل"
  },
  "m095": {
    "en": "Purchase or acquisition",
    "ar": "شراء أو استملاك"
  },
  "m096": {
    "en": "For priority properties where feasibility is clear.",
    "ar": "للعقارات ذات الأولوية عندما تكون الجدوى واضحة."
  },
  "m097": {
    "en": "Long-term lease",
    "ar": "إيجار طويل الأمد"
  },
  "m098": {
    "en": "With the investor committed to restoration and operation.",
    "ar": "مع التزام المستثمر بالترميم والتشغيل."
  },
  "m099": {
    "en": "Revenue-sharing partnership",
    "ar": "شراكة إيرادات"
  },
  "m100": {
    "en": "Sharing returns between the owner and operator according to the activity.",
    "ar": "تقاسم العائد بين المالك والمشغل بحسب النشاط."
  },
  "m101": {
    "en": "16 — Financial Returns",
    "ar": "16 — العائد المالي"
  },
  "m102": {
    "en": "Multiple Revenue Sources without Assumed Figures",
    "ar": "مصادر إيراد متعددة دون أرقام افتراضية"
  },
  "m103": {
    "en": "Property rents after restoration",
    "ar": "بدلات إيجار العقارات بعد الترميم"
  },
  "m104": {
    "en": "Use and investment fees",
    "ar": "رسوم الانتفاع والاستثمار"
  },
  "m105": {
    "en": "A share of revenue from selected enterprises",
    "ar": "نسبة من إيرادات بعض المشروعات"
  },
  "m106": {
    "en": "Museum, exhibition and experience tickets",
    "ar": "تذاكر المتاحف والمعارض والتجارب"
  },
  "m107": {
    "en": "Event and seasonal market fees",
    "ar": "رسوم الفعاليات والأسواق الموسمية"
  },
  "m108": {
    "en": "Sponsorships and event naming rights",
    "ar": "الرعايات وحقوق تسمية الفعاليات"
  },
  "m109": {
    "en": "Parking and mobility services",
    "ar": "مواقف السيارات وخدمات التنقل"
  },
  "m110": {
    "en": "Photography and media production licensing",
    "ar": "ترخيص التصوير والإنتاج الإعلامي"
  },
  "m111": {
    "en": "A unified online shop and paid guided tours",
    "ar": "متجر رقمي موحد وجولات سياحية مدفوعة"
  },
  "m112": {
    "en": "Increased economic value and tourism activity",
    "ar": "ارتفاع القيمة الاقتصادية والنشاط السياحي"
  },
  "m113": {
    "en": "[Acquisition, restoration and operating costs and revenues will be added after financial and property assessments are completed]",
    "ar": "[تدرج كلفة التملك والترميم والتشغيل والإيرادات بعد استكمال التقييم المالي والعقاري]"
  },
  "m114": {
    "en": "17 — Digital Services",
    "ar": "17 — الخدمات الرقمية"
  },
  "m115": {
    "en": "A Digital Layer That Connects the Street Experience",
    "ar": "طبقة رقمية تحول الشارع إلى تجربة متصلة"
  },
  "m116": {
    "en": "A street website and web application with an interactive map.",
    "ar": "موقع وتطبيق ويب للشارع مع خريطة تفاعلية."
  },
  "m117": {
    "en": "A three-dimensional virtual tour before and after restoration.",
    "ar": "جولة افتراضية ثلاثية الأبعاد قبل وبعد الترميم."
  },
  "m118": {
    "en": "Unified ticketing and reservations for events and experiences.",
    "ar": "تذاكر وحجوزات موحدة للفعاليات والتجارب."
  },
  "m119": {
    "en": "QR codes and an audio guide in Arabic and English.",
    "ar": "رموز QR ودليل صوتي بالعربية والإنجليزية."
  },
  "m120": {
    "en": "Augmented reality, an online shop, a loyalty programme and a digital passport.",
    "ar": "واقع معزز، متجر إلكتروني، برنامج ولاء، وجواز رقمي."
  },
  "m121": {
    "en": "A dashboard for visitors, bookings and revenue, with a digital archive of drawings, photographs and documents.",
    "ar": "لوحة تحكم للزوار والحجوزات والإيرادات، مع أرشيف رقمي للمخططات والصور والوثائق."
  },
  "m122": {
    "en": "Digital services support operation, measurement and revenue generation, rather than serving solely as promotional additions.",
    "ar": "الخدمات الرقمية وسيلة للتشغيل والقياس وتحقيق الإيرادات، وليست إضافات دعائية."
  },
  "m123": {
    "en": "18 — Visitor Journey",
    "ar": "18 — رحلة الزائر"
  },
  "m124": {
    "en": "A Clear Journey from Discovery to Return Visits",
    "ar": "رحلة قصيرة وواضحة من الاكتشاف إلى العودة"
  },
  "m125": {
    "en": "Discover the project online",
    "ar": "اكتشاف المشروع رقمياً"
  },
  "m126": {
    "en": "Arrive from the Corniche or a hotel",
    "ar": "الوصول من الكورنيش أو الفندق"
  },
  "m127": {
    "en": "Enter through the street gateway",
    "ar": "الدخول عبر بوابة الشارع"
  },
  "m128": {
    "en": "Explore the houses and activities",
    "ar": "استكشاف البيوت والأنشطة"
  },
  "m129": {
    "en": "Book or purchase",
    "ar": "الحجز أو الشراء"
  },
  "m130": {
    "en": "Attend an event or experience",
    "ar": "حضور فعالية أو تجربة"
  },
  "m131": {
    "en": "Share the visit and return",
    "ar": "مشاركة الزيارة والعودة مجدداً"
  },
  "m132": {
    "en": "19 — Implementation Plan",
    "ar": "19 — خطة التنفيذ"
  },
  "m133": {
    "en": "Phased Development Adapted to Assessment Findings",
    "ar": "برنامج تطوير مرحلي قابل للتكيّف مع نتائج التقييم"
  },
  "m134": {
    "en": "The pace of implementation will depend on structural and property surveys, acquisition or contracting procedures, restoration priorities, infrastructure readiness and the release of investment opportunities.",
    "ar": "تتحدد وتيرة التنفيذ وفق نتائج المسح الإنشائي والعقاري، وإجراءات التملك أو التعاقد، وأولويات الترميم، وجاهزية البنية التحتية، وطرح الفرص الاستثمارية."
  },
  "m135": {
    "en": "01 — Documentation and Assessment",
    "ar": "01 — التوثيق والتقييم"
  },
  "m136": {
    "en": "A thorough understanding before intervention",
    "ar": "قراءة دقيقة قبل التدخل"
  },
  "m137": {
    "en": "Property and structural surveys.",
    "ar": "المسح العقاري والإنشائي."
  },
  "m138": {
    "en": "Documenting houses and architectural features.",
    "ar": "توثيق البيوت والعناصر المعمارية."
  },
  "m139": {
    "en": "Identifying priorities and risks.",
    "ar": "تحديد الأولويات والمخاطر."
  },
  "m140": {
    "en": "02 — Infrastructure Improvements",
    "ar": "02 — معالجة البنية التحتية"
  },
  "m141": {
    "en": "Organizing networks and services",
    "ar": "تنظيم الشبكات والخدمات"
  },
  "m142": {
    "en": "Removing hazardous encroachments.",
    "ar": "إزالة التجاوزات الخطرة."
  },
  "m143": {
    "en": "Upgrading wiring and networks.",
    "ar": "معالجة الأسلاك والشبكات."
  },
  "m144": {
    "en": "Improving paving, lighting and planting.",
    "ar": "تحسين التبليط والإنارة والتشجير."
  },
  "m145": {
    "en": "03 — Restoration and Rehabilitation",
    "ar": "03 — الترميم وإعادة التأهيل"
  },
  "m146": {
    "en": "Preserving architectural value",
    "ar": "حفظ القيمة العمرانية"
  },
  "m147": {
    "en": "Restoring priority properties.",
    "ar": "ترميم العقارات ذات الأولوية."
  },
  "m148": {
    "en": "Coordinating facades and wayfinding.",
    "ar": "توحيد الواجهات والإرشاد."
  },
  "m149": {
    "en": "Preparing buildings for suitable uses.",
    "ar": "تجهيز المباني للاستخدام المناسب."
  },
  "m150": {
    "en": "04 — Investment Offering and Operation",
    "ar": "04 — الطرح والتشغيل الاستثماري"
  },
  "m151": {
    "en": "Activating heritage assets",
    "ar": "تحويل الأصول إلى نشاط"
  },
  "m152": {
    "en": "Offering investment opportunities.",
    "ar": "طرح فرص الاستثمار."
  },
  "m153": {
    "en": "Launching the first activities.",
    "ar": "تشغيل الأنشطة الأولى."
  },
  "m154": {
    "en": "Measuring demand and visitor experience.",
    "ar": "قياس الطلب وتجربة الزائر."
  },
  "m155": {
    "en": "05 — Expansion and Continuous Improvement",
    "ar": "05 — التوسع والتطوير المستمر"
  },
  "m156": {
    "en": "Improving performance and broadening impact",
    "ar": "تحسين الأداء وتوسيع الأثر"
  },
  "m157": {
    "en": "Expanding successful activities.",
    "ar": "توسيع الأنشطة الناجحة."
  },
  "m158": {
    "en": "Connecting the project with hotels and tourism.",
    "ar": "ربط المشروع بالفنادق والسياحة."
  },
  "m159": {
    "en": "Refining the operating model using performance indicators.",
    "ar": "تحسين نموذج التشغيل وفق المؤشرات."
  },
  "m160": {
    "en": "20 — A Focused Start",
    "ar": "20 — البداية الذكية"
  },
  "m161": {
    "en": "The Project Can Begin before All 16 Houses Are Ready",
    "ar": "لا ننتظر اكتمال 16 بيتاً حتى يبدأ المشروع"
  },
  "m162": {
    "en": "The street entrance from Abu Nawas.",
    "ar": "مدخل الشارع من جهة أبو نؤاس."
  },
  "m163": {
    "en": "The House of Antiques Museum as an established attraction.",
    "ar": "متحف بيت التحفيات كنقطة جذب قائمة."
  },
  "m164": {
    "en": "Two or three priority houses.",
    "ar": "بيتان أو ثلاثة بيوت ذات أولوية."
  },
  "m165": {
    "en": "Cleaning, organizing and lighting a clearly defined part of the street.",
    "ar": "تنظيف وتنظيم وإنارة جزء واضح من الشارع."
  },
  "m166": {
    "en": "An opening event and a virtual tour documenting the transformation.",
    "ar": "فعالية افتتاحية وجولة افتراضية توثق التحول."
  },
  "m167": {
    "en": "Offering the first investment opportunities.",
    "ar": "طرح أول الفرص الاستثمارية."
  },
  "m168": {
    "en": "The aim: deliver a tangible early result, test operations and build investor confidence before expansion.",
    "ar": "الهدف: نتيجة ملموسة وسريعة، اختبار التشغيل، وبناء ثقة المستثمرين قبل التوسع."
  },
  "m169": {
    "en": "21 — Marketing Campaign",
    "ar": "21 — الحملة التسويقية"
  },
  "m170": {
    "en": "Abu Nawas Heritage Street — Experience Baghdad",
    "ar": "الشارع التراثي في أبو نؤاس — بغداد التي تُعاش"
  },
  "m171": {
    "en": "Discover Baghdad through Its Historic Doorway",
    "ar": "بغداد تُفتح من بابها القديم"
  },
  "m172": {
    "en": "Before opening",
    "ar": "قبل الافتتاح"
  },
  "m173": {
    "en": "House stories, before-and-after views, restoration diaries and interviews with residents, artists and craftspeople.",
    "ar": "قصص البيوت، قبل وبعد، يوميات الترميم، ولقاءات مع سكان وفنانين وحرفيين."
  },
  "m174": {
    "en": "Launch",
    "ar": "الإطلاق"
  },
  "m175": {
    "en": "A cultural and arts week, a crafts and antiques market, guided tours and hotel partnerships.",
    "ar": "أسبوع ثقافي وفني، سوق للحرف والأنتيك، جولات مرشدة، وتعاون مع الفنادق."
  },
  "m176": {
    "en": "After opening",
    "ar": "بعد الافتتاح"
  },
  "m177": {
    "en": "An annual calendar, museum nights, seasonal markets, visitor packages and targeted campaigns.",
    "ar": "تقويم سنوي، ليالي متاحف، أسواق موسمية، باقات زيارة وحملات موجهة."
  },
  "m178": {
    "en": "22 — Success Indicators",
    "ar": "22 — مؤشرات النجاح"
  },
  "m179": {
    "en": "Measurable Indicators from Day One",
    "ar": "مؤشرات قابلة للقياس منذ اليوم الأول"
  },
  "m180": {
    "en": "Number of restored houses",
    "ar": "عدد البيوت المرممة"
  },
  "m181": {
    "en": "Investment occupancy rate",
    "ar": "نسبة الإشغال الاستثماري"
  },
  "m182": {
    "en": "Visitor numbers",
    "ar": "عدد الزوار"
  },
  "m183": {
    "en": "Average visitor spending",
    "ar": "متوسط إنفاق الزائر"
  },
  "m184": {
    "en": "Direct Revenue",
    "ar": "الإيرادات المباشرة"
  },
  "m185": {
    "en": "Number of events",
    "ar": "عدد الفعاليات"
  },
  "m186": {
    "en": "Jobs created",
    "ar": "فرص العمل المستحدثة"
  },
  "m187": {
    "en": "Participation of local businesses and crafts",
    "ar": "مشاركة المشاريع والحرف المحلية"
  },
  "m188": {
    "en": "Visitor satisfaction",
    "ar": "رضا الزوار"
  },
  "m189": {
    "en": "Building conservation standards",
    "ar": "مستوى الحفاظ على المباني"
  },
  "m190": {
    "en": "Digital reach and bookings",
    "ar": "الوصول الرقمي والحجوزات"
  },
  "m191": {
    "en": "Repeat visits",
    "ar": "تكرار الزيارة"
  },
  "m192": {
    "en": "23 — Conclusion",
    "ar": "23 — الخاتمة"
  },
  "m193": {
    "en": "Revitalizing the Street Is an Investment in Baghdad’s Memory and Tourism Economy",
    "ar": "إحياء الشارع استثمار في ذاكرة بغداد واقتصادها السياحي"
  },
  "m194": {
    "en": "Abu Nawas Heritage Street has the essential ingredients for success: location, architecture, history, hotels, the Corniche and an established attraction. The task is to bring these elements together in one project that can be implemented, measured and invested in.",
    "ar": "يمتلك الشارع التراثي في أبو نؤاس عناصر النجاح الأساسية: الموقع، العمارة، التاريخ، الفنادق، الكورنيش، ونقطة جذب قائمة. المطلوب هو جمع هذه العناصر ضمن مشروع واحد قابل للتنفيذ والقياس والاستثمار."
  },
  "m195": {
    "en": "From 16 houses… a new destination for Baghdad",
    "ar": "من 16 بيتاً… تبدأ وجهة جديدة لبغداد"
  },
  "m196": {
    "en": "This presentation was prepared by Abaad Aliraq Software Solutions",
    "ar": "تم إعداد هذا العرض التقديمي بواسطة مكتب أبعاد العراق للحلول البرمجية"
  },
  "m197": {
    "en": "Visit the House of Antiques Museum website",
    "ar": "زيارة الموقع الإلكتروني لمتحف بيت التحفيات"
  },
  "m198": {
    "en": "01 — Connecting Route",
    "ar": "01 — محور رابط"
  },
  "m199": {
    "en": "Connecting route",
    "ar": "محور رابط"
  },
  "m200": {
    "en": "Links Abu Nawas Street with Al-Saadoon Street, providing a direct connection between the riverfront and the city centre.",
    "ar": "يربط شارع أبو نؤاس بشارع السعدون ويوفر اتصالاً مباشراً بين واجهة النهر ومركز المدينة."
  },
  "m201": {
    "en": "02 — Corniche Gateway",
    "ar": "02 — بوابة الكورنيش"
  },
  "m202": {
    "en": "Corniche gateway",
    "ar": "بوابة الكورنيش"
  },
  "m203": {
    "en": "The street entrance is opposite the entrance and exit gate of the new Corniche project.",
    "ar": "يقع مدخل الشارع مقابل بوابة الدخول والخروج من مشروع الكورنيش الجديد."
  },
  "m204": {
    "en": "03 — Hotel Surroundings",
    "ar": "03 — محيط فندقي"
  },
  "m205": {
    "en": "Hotel surroundings",
    "ar": "محيط فندقي"
  },
  "m206": {
    "en": "A hotel stands at the corner of the street entrance, with Baghdad Hotel and several operating and under-construction hotels nearby.",
    "ar": "يقع فندق عند ركن مدخل الشارع، إضافة إلى قربه من فندق بغداد وعدة فنادق عاملة وأخرى قيد الإنشاء."
  },
  "m207": {
    "en": "04 — Established Attraction",
    "ar": "04 — نقطة جذب قائمة"
  },
  "m208": {
    "en": "Established attraction",
    "ar": "نقطة جذب قائمة"
  },
  "m209": {
    "en": "The street hosts the House of Antiques Museum, a museum and antiques shop that has attracted tourists, artists and art and heritage enthusiasts for decades.",
    "ar": "يضم الشارع متحف بيت التحفيات، وهو متحف ومتجر أنتيك يستقطب السياح والفنانين والمهتمين بالفن والتراث منذ عقود."
  },
  "m210": {
    "en": "05 — Walkable Access",
    "ar": "05 — قابلية الحركة سيراً"
  },
  "m211": {
    "en": "Walkable access",
    "ar": "قابلية الحركة سيراً"
  },
  "m212": {
    "en": "The street’s location allows hotel guests and Corniche visitors to reach it on foot without a separate transport route.",
    "ar": "يسمح موقع الشارع بوصول نزلاء الفنادق وزوار الكورنيش إليه سيراً دون الحاجة إلى مسار نقل منفصل."
  },
  "m213": {
    "en": "06 — Tourism Connections",
    "ar": "06 — فرصة للربط السياحي"
  },
  "m214": {
    "en": "Tourism connections",
    "ar": "فرصة للربط السياحي"
  },
  "m215": {
    "en": "The street can be integrated into visitor routes connecting the Corniche, hotels, the museum and future cultural projects.",
    "ar": "يمكن دمج الشارع ضمن مسارات زيارة تربط الكورنيش والفنادق والمتحف والمشروعات الثقافية المستقبلية."
  },
  "m216": {
    "en": "Open location in Google Maps",
    "ar": "فتح الموقع على خرائط Google"
  },
  "m217": {
    "en": "Crafts and Creative Industries",
    "ar": "الحرف والصناعات الإبداعية"
  },
  "m218": {
    "en": "Supporting craftswomen and women-led businesses specializing in heritage fashion, embroidery, art, design, handmade products and cultural collectibles.",
    "ar": "دعم الحرفيات والمشاريع النسائية المتخصصة بالأزياء التراثية، التطريز، الفنون، التصميم، المنتجات اليدوية والمقتنيات الثقافية."
  },
  "m219": {
    "en": "Hospitality and Food",
    "ar": "الضيافة والطعام"
  },
  "m220": {
    "en": "Providing operating and investment opportunities for women-led businesses in Iraqi food, hospitality, cultural cafés and culinary experiences.",
    "ar": "إتاحة فرص تشغيل واستثمار لمشاريع نسائية في الطعام العراقي، الضيافة، المقاهي الثقافية وتجارب الطبخ."
  },
  "m221": {
    "en": "Guiding and Tourism Experiences",
    "ar": "الإرشاد والتجارب السياحية"
  },
  "m222": {
    "en": "Training female tour guides and involving them in managing tours, cultural experiences and events.",
    "ar": "تدريب مرشدات سياحيات وإشراكهن في إدارة الجولات، التجارب الثقافية والفعاليات."
  },
  "m223": {
    "en": "Marketing and Digital Commerce",
    "ar": "التسويق والتجارة الرقمية"
  },
  "m224": {
    "en": "Training participants to manage online shops, photography, digital marketing and product sales through the project’s unified platform.",
    "ar": "تدريب المشاركات على إدارة المتاجر الإلكترونية، التصوير، التسويق الرقمي وبيع المنتجات داخل المنصة الموحدة للمشروع."
  },
  "m225": {
    "en": "Arts and Events",
    "ar": "الفنون والفعاليات"
  },
  "m226": {
    "en": "Involving female artists, designers and arts graduates in exhibitions, workshops, documentation and cultural programmes.",
    "ar": "إشراك الفنانات والمصممات وخريجات كليات الفنون في المعارض، الورش، التوثيق والبرامج الثقافية."
  },
  "m227": {
    "en": "Operating and Supply Opportunities",
    "ar": "فرص التشغيل والتوريد"
  },
  "m228": {
    "en": "Giving qualified women-led businesses fair access to operating, supply and service contracts.",
    "ar": "منح المشاريع النسائية المؤهلة فرصة عادلة للمشاركة في عقود التشغيل والتوريد والخدمات."
  },
  "m229": {
    "en": "Number of participating women-led businesses.",
    "ar": "عدد المشاريع النسائية المشاركة."
  },
  "m230": {
    "en": "Number of jobs created.",
    "ar": "عدد فرص العمل المستحدثة."
  },
  "m231": {
    "en": "Value of sales achieved.",
    "ar": "قيمة المبيعات المحققة."
  },
  "m232": {
    "en": "Number of women receiving training.",
    "ar": "عدد المستفيدات من التدريب."
  },
  "m233": {
    "en": "Business continuity rate.",
    "ar": "نسبة استمرارية المشاريع."
  },
  "m234": {
    "en": "Value of operating and supply contracts.",
    "ar": "قيمة عقود التشغيل والتوريد."
  },
  "m235": {
    "en": "Rents from houses and facilities after rehabilitation.",
    "ar": "إيجارات البيوت والمرافق بعد التأهيل."
  },
  "m236": {
    "en": "Use and investment fees.",
    "ar": "رسوم الانتفاع والاستثمار."
  },
  "m237": {
    "en": "A share of revenue from selected enterprises.",
    "ar": "نسبة مشاركة من إيرادات بعض المشروعات."
  },
  "m238": {
    "en": "Museum, exhibition and experience tickets.",
    "ar": "تذاكر المتاحف والمعارض والتجارب."
  },
  "m239": {
    "en": "Guided tour fees.",
    "ar": "رسوم الجولات السياحية."
  },
  "m240": {
    "en": "Event and seasonal market fees.",
    "ar": "رسوم الفعاليات والأسواق الموسمية."
  },
  "m241": {
    "en": "Commercial and cultural sponsorships.",
    "ar": "الرعايات التجارية والثقافية."
  },
  "m242": {
    "en": "Photography and media production licences.",
    "ar": "تراخيص التصوير والإنتاج الإعلامي."
  },
  "m243": {
    "en": "Revenue from the unified online shop.",
    "ar": "إيرادات المتجر الإلكتروني الموحد."
  },
  "m244": {
    "en": "Parking and transport services, if adopted.",
    "ar": "خدمات مواقف السيارات والنقل عند اعتمادها."
  },
  "m245": {
    "en": "Increasing the economic value of surrounding properties.",
    "ar": "رفع القيمة الاقتصادية للعقارات المحيطة."
  },
  "m246": {
    "en": "Increasing spending by tourists and hotel guests in the area.",
    "ar": "زيادة إنفاق السياح ونزلاء الفنادق في المنطقة."
  },
  "m247": {
    "en": "Stimulating nearby restaurants, shops and services.",
    "ar": "تنشيط المطاعم والمتاجر والخدمات المجاورة."
  },
  "m248": {
    "en": "Creating direct and indirect jobs.",
    "ar": "خلق فرص عمل مباشرة وغير مباشرة."
  },
  "m249": {
    "en": "Attracting new investment to the area.",
    "ar": "جذب استثمارات جديدة إلى المنطقة."
  },
  "m250": {
    "en": "Extending visitors’ time in central Baghdad.",
    "ar": "زيادة مدة بقاء الزائر داخل مركز بغداد."
  },
  "m251": {
    "en": "Supporting local cultural and craft industries.",
    "ar": "دعم الصناعات الثقافية والحرفية المحلية."
  },
  "m252": {
    "en": "Houses included in the phase",
    "ar": "عدد البيوت الداخلة في المرحلة"
  },
  "m253": {
    "en": "house",
    "ar": "بيت"
  },
  "m254": {
    "en": "Houses included in the scenario’s purchase and restoration costs.",
    "ar": "عدد البيوت التي تدخل ضمن كلفة الشراء والترميم في السيناريو."
  },
  "m255": {
    "en": "Average house area",
    "ar": "متوسط مساحة البيت"
  },
  "m256": {
    "en": "m²",
    "ar": "م²"
  },
  "m257": {
    "en": "An assumed average between 100 and 250 m² until each house’s area is confirmed.",
    "ar": "متوسط افتراضي بين 100 و250 م² إلى حين تثبيت مساحة كل بيت."
  },
  "m258": {
    "en": "Purchase price per square metre",
    "ar": "سعر شراء المتر"
  },
  "m259": {
    "en": "USD/m²",
    "ar": "دولار/م²"
  },
  "m260": {
    "en": "An estimated price for simulation purposes only; this is not a property valuation.",
    "ar": "سعر تقديري للمتر لأغراض المحاكاة فقط، وليس تقييماً عقارياً."
  },
  "m261": {
    "en": "Restoration cost per square metre",
    "ar": "كلفة الترميم لكل متر مربع"
  },
  "m262": {
    "en": "An assumed cost covering architectural rehabilitation and essential services.",
    "ar": "كلفة افتراضية تشمل أعمال التأهيل المعماري والخدمات الأساسية."
  },
  "m263": {
    "en": "Houses offered for investment",
    "ar": "عدد البيوت المطروحة للاستثمار"
  },
  "m264": {
    "en": "Houses generating rental revenue in the current scenario.",
    "ar": "عدد البيوت التي تحقق إيراد إيجار ضمن السيناريو الحالي."
  },
  "m265": {
    "en": "Average monthly rent per square metre",
    "ar": "متوسط الإيجار الشهري لكل متر مربع"
  },
  "m266": {
    "en": "An assumed average monthly rent after rehabilitation and operation.",
    "ar": "متوسط افتراضي لبدل الإيجار الشهري بعد التأهيل والتشغيل."
  },
  "m267": {
    "en": "Occupancy rate",
    "ar": "نسبة الإشغال"
  },
  "m268": {
    "en": "Expected annual utilization rate of the spaces offered for investment.",
    "ar": "النسبة السنوية المتوقعة لاستثمار المساحات المطروحة."
  },
  "m269": {
    "en": "Annual visitor numbers",
    "ar": "عدد الزوار السنوي"
  },
  "m270": {
    "en": "visitor",
    "ar": "زائر"
  },
  "m271": {
    "en": "Annual visitors paying for tickets or tours.",
    "ar": "عدد الزوار المدفوعين للتذاكر أو الجولات خلال سنة."
  },
  "m272": {
    "en": "Average ticket or tour price",
    "ar": "متوسط سعر التذكرة أو الجولة"
  },
  "m273": {
    "en": "USD",
    "ar": "دولار"
  },
  "m274": {
    "en": "Average admission or cultural tour price.",
    "ar": "متوسط سعر الدخول أو الجولة الثقافية."
  },
  "m275": {
    "en": "Annual number of events",
    "ar": "عدد الفعاليات السنوي"
  },
  "m276": {
    "en": "event",
    "ar": "فعالية"
  },
  "m277": {
    "en": "Revenue-generating events, seasonal markets and workshops.",
    "ar": "الفعاليات والأسواق الموسمية والورش المدرة للإيراد."
  },
  "m278": {
    "en": "Average revenue per event",
    "ar": "متوسط إيراد الفعالية"
  },
  "m279": {
    "en": "Average direct revenue from each event.",
    "ar": "متوسط الإيراد المباشر لكل فعالية."
  },
  "m280": {
    "en": "Annual sponsorship revenue",
    "ar": "إيرادات الرعاية السنوية"
  },
  "m281": {
    "en": "Potential cultural and commercial sponsorships; adjustable.",
    "ar": "رعايات ثقافية وتجارية محتملة قابلة للتعديل."
  },
  "m282": {
    "en": "Photography and licensing revenue",
    "ar": "إيرادات التصوير والتراخيص"
  },
  "m283": {
    "en": "Photography, media production and site-related usage rights.",
    "ar": "تصوير وإنتاج إعلامي وحقوق استخدام مرتبطة بالموقع."
  },
  "m284": {
    "en": "Digital and online shop revenue",
    "ar": "الإيرادات الرقمية والمتجر الإلكتروني"
  },
  "m285": {
    "en": "Digital sales, bookings, a unified shop and online experiences.",
    "ar": "بيع رقمي، حجوزات، متجر موحد، وتجارب إلكترونية."
  },
  "m286": {
    "en": "Investor sales subject to revenue sharing",
    "ar": "مبيعات المستثمرين الخاضعة للمشاركة"
  },
  "m287": {
    "en": "Total sales of selected enterprises to which the project’s revenue share applies.",
    "ar": "إجمالي مبيعات مشروعات مختارة تحسب عليها نسبة مشاركة المشروع."
  },
  "m288": {
    "en": "Project’s share of investor sales",
    "ar": "نسبة مشاركة المشروع من مبيعات المستثمرين"
  },
  "m289": {
    "en": "An assumed share of selected enterprises’ sales, subject to contractual agreement.",
    "ar": "نسبة افتراضية من مبيعات بعض المشروعات عند اعتمادها تعاقدياً."
  },
  "m290": {
    "en": "Annual operating cost",
    "ar": "كلفة التشغيل السنوية"
  },
  "m291": {
    "en": "Annual management, operation, maintenance, marketing and services.",
    "ar": "إدارة وتشغيل وصيانة وتسويق وخدمات سنوية."
  },
  "m292": {
    "en": "Additional setup costs",
    "ar": "أي كلفة تأسيس مضافة"
  },
  "m293": {
    "en": "Initial equipment, systems or launch expenses outside purchase and restoration costs.",
    "ar": "تجهيزات تأسيسية أو أنظمة أو مصاريف إطلاق غير داخلة في الشراء والترميم."
  },
  "m294": {
    "en": "Annual growth rate",
    "ar": "معدل النمو السنوي"
  },
  "m295": {
    "en": "Used only in the five-year projection; no hidden growth rate is included in the code.",
    "ar": "يستخدم فقط في توقع خمس سنوات، ولا توجد نسبة نمو مخفية داخل الكود."
  },
  "m296": {
    "en": "{v0} USD",
    "ar": "{v0} دولار"
  },
  "m297": {
    "en": "Partnership and Sponsorship Opportunity",
    "ar": "فرصة للشراكة والرعاية"
  },
  "m298": {
    "en": "A sponsor or institution specializing in women’s empowerment can support training, equipment and business development programmes, with recognition as a programme partner and clear measurement of sponsorship impact.",
    "ar": "يمكن لجهة راعية أو مؤسسة متخصصة في تمكين المرأة دعم التدريب والتجهيز وبرامج تطوير المشاريع، مقابل الظهور كشريك للبرنامج وقياس أثر الرعاية بصورة واضحة."
  },
  "m299": {
    "en": "Placeholder counters",
    "ar": "عدادات بقيم مؤقتة"
  },
  "m300": {
    "en": "Number of businesses",
    "ar": "عدد المشاريع"
  },
  "m301": {
    "en": "Jobs",
    "ar": "فرص العمل"
  },
  "m302": {
    "en": "Sales",
    "ar": "المبيعات"
  },
  "m303": {
    "en": "Beneficiaries",
    "ar": "المستفيدات"
  },
  "m304": {
    "en": "Placeholder value",
    "ar": "قيمة مؤقتة"
  },
  "m305": {
    "en": "Indirect Economic Returns",
    "ar": "العائد الاقتصادي غير المباشر"
  },
  "m306": {
    "en": "Revenue Generation Pathway",
    "ar": "مسار تحقيق الإيرادات"
  },
  "m307": {
    "en": "Heritage assets",
    "ar": "أصول تراثية"
  },
  "m308": {
    "en": "Rehabilitation and operation",
    "ar": "تأهيل وتشغيل"
  },
  "m309": {
    "en": "Tourism and commercial activity",
    "ar": "نشاط سياحي وتجاري"
  },
  "m310": {
    "en": "Direct revenue",
    "ar": "إيرادات مباشرة"
  },
  "m311": {
    "en": "Reinvestment and expansion",
    "ar": "إعادة استثمار وتوسع"
  },
  "m312": {
    "en": "The project combines rent, operations, tickets, events, sponsorship and digital services rather than relying on a single income source.",
    "ar": "لا يعتمد المشروع على مصدر دخل واحد، بل يجمع بين الإيجار والتشغيل والتذاكر والفعاليات والرعاية والخدمات الرقمية."
  },
  "m313": {
    "en": "Rent",
    "ar": "إيجارات"
  },
  "m314": {
    "en": "Tickets",
    "ar": "تذاكر"
  },
  "m315": {
    "en": "Events",
    "ar": "فعاليات"
  },
  "m316": {
    "en": "Sponsorships",
    "ar": "رعايات"
  },
  "m317": {
    "en": "Licences",
    "ar": "تراخيص"
  },
  "m318": {
    "en": "Digital",
    "ar": "رقمي"
  },
  "m319": {
    "en": "Net",
    "ar": "الصافي"
  },
  "m320": {
    "en": "Scenario",
    "ar": "سيناريو"
  },
  "m321": {
    "en": "Year {v0}",
    "ar": "السنة {v0}"
  },
  "m322": {
    "en": "Total revenue: {v0}",
    "ar": "إجمالي الإيرادات: {v0}"
  },
  "m323": {
    "en": "Net revenue: {v0}",
    "ar": "صافي الإيراد: {v0}"
  },
  "m324": {
    "en": "Revenue: {v0}",
    "ar": "الإيراد: {v0}"
  },
  "m325": {
    "en": "Net: {v0}",
    "ar": "الصافي: {v0}"
  },
  "m326": {
    "en": "House rents",
    "ar": "إيجارات البيوت"
  },
  "m327": {
    "en": "Tickets and tours",
    "ar": "التذاكر والجولات"
  },
  "m328": {
    "en": "Events",
    "ar": "الفعاليات"
  },
  "m329": {
    "en": "Sponsorships",
    "ar": "الرعايات"
  },
  "m330": {
    "en": "Photography and licensing",
    "ar": "التصوير والتراخيص"
  },
  "m331": {
    "en": "Digital revenue",
    "ar": "الإيرادات الرقمية"
  },
  "m332": {
    "en": "Total",
    "ar": "الإجمالي"
  },
  "m333": {
    "en": "Estimated property value",
    "ar": "القيمة العقارية التقديرية"
  },
  "m334": {
    "en": "Estimated restoration cost",
    "ar": "كلفة الترميم التقديرية"
  },
  "m335": {
    "en": "Total initial investment",
    "ar": "إجمالي الاستثمار الأولي"
  },
  "m336": {
    "en": "Annual rental revenue",
    "ar": "إيرادات الإيجارات السنوية"
  },
  "m337": {
    "en": "Visitor and event revenue",
    "ar": "إيرادات الزوار والفعاليات"
  },
  "m338": {
    "en": "Total annual revenue",
    "ar": "إجمالي الإيرادات السنوية"
  },
  "m339": {
    "en": "Net operating income",
    "ar": "صافي الإيراد التشغيلي"
  },
  "m340": {
    "en": "Approximate payback period",
    "ar": "فترة الاسترداد التقريبية"
  },
  "m341": {
    "en": "{v0} years",
    "ar": "{v0} سنة"
  },
  "m342": {
    "en": "Not available under the current scenario",
    "ar": "غير متاح ضمن السيناريو الحالي"
  },
  "m343": {
    "en": "Annual operating return",
    "ar": "العائد التشغيلي السنوي"
  },
  "m344": {
    "en": "The figures below are preliminary assumptions for simulation purposes. They do not constitute a property valuation or a final feasibility study.",
    "ar": "الأرقام الواردة أدناه افتراضات أولية لأغراض المحاكاة، ولا تمثل تقييماً عقارياً أو دراسة جدوى نهائية."
  },
  "m345": {
    "en": "Simulation scenarios",
    "ar": "سيناريوهات المحاكاة"
  },
  "m346": {
    "en": "Simulation inputs",
    "ar": "مدخلات المحاكاة"
  },
  "m347": {
    "en": "{v0}, manual entry",
    "ar": "{v0} كتابة يدوية"
  },
  "m348": {
    "en": "Simulation outputs",
    "ar": "مخرجات المحاكاة"
  },
  "m349": {
    "en": "Preliminary Property Value Range",
    "ar": "نطاق القيمة العقارية الأولية"
  },
  "m350": {
    "en": "Theoretical minimum: 16 × 100 m² × 2,000 USD = 3,200,000 USD",
    "ar": "الحد الأدنى النظري: 16 × 100 م² × 2,000 دولار = 3,200,000 دولار"
  },
  "m351": {
    "en": "Theoretical maximum: 16 × 250 m² × 2,500 USD = 10,000,000 USD",
    "ar": "الحد الأعلى النظري: 16 × 250 م² × 2,500 دولار = 10,000,000 دولار"
  },
  "m352": {
    "en": "This range does not represent a final purchase cost. Each house’s area, structural condition and market value require separate assessment.",
    "ar": "هذا النطاق لا يمثل كلفة شراء نهائية، لأن المساحة والحالة الإنشائية والقيمة السوقية لكل بيت تحتاج إلى تقييم منفصل."
  },
  "m353": {
    "en": "Annual revenue distribution",
    "ar": "توزيع الإيرادات السنوية"
  },
  "m354": {
    "en": "Scenario comparison",
    "ar": "مقارنة السيناريوهات"
  },
  "m355": {
    "en": "Five-year projection",
    "ar": "توقع خمس سنوات"
  },
  "m356": {
    "en": "Print results",
    "ar": "طباعة النتائج"
  },
  "m357": {
    "en": "Revenue source",
    "ar": "مصدر الإيراد"
  },
  "m358": {
    "en": "Annual",
    "ar": "سنوي"
  },
  "m359": {
    "en": "Five years",
    "ar": "خمس سنوات"
  },
  "m360": {
    "en": "Share of total",
    "ar": "النسبة من الإجمالي"
  },
  "m361": {
    "en": "Phase One",
    "ar": "المرحلة الأولى"
  },
  "m362": {
    "en": "Rehabilitating and operating the project street and measuring actual performance.",
    "ar": "تأهيل وتشغيل الشارع موضوع المشروع وقياس الأداء الفعلي."
  },
  "m363": {
    "en": "Phase Two",
    "ar": "المرحلة الثانية"
  },
  "m364": {
    "en": "Connecting adjacent heritage side streets through identity, wayfinding, digital services and events.",
    "ar": "ربط الفروع التراثية المجاورة بالهوية والإرشاد والخدمات الرقمية والفعاليات."
  },
  "m365": {
    "en": "Phase Three",
    "ar": "المرحلة الثالثة"
  },
  "m366": {
    "en": "Creating an interconnected heritage district linked to Abu Nawas, Al-Saadoon, the Corniche and surrounding hotels.",
    "ar": "إنشاء منطقة تراثية مترابطة ترتبط بأبو نؤاس والسعدون والكورنيش والفنادق المحيطة."
  },
  "m367": {
    "en": "Documenting heritage houses in adjacent side streets.",
    "ar": "توثيق البيوت التراثية في الفروع المجاورة."
  },
  "m368": {
    "en": "Identifying priority properties.",
    "ar": "تحديد العقارات ذات الأولوية."
  },
  "m369": {
    "en": "Coordinating architectural identity and wayfinding.",
    "ar": "توحيد الهوية العمرانية والإرشادية."
  },
  "m370": {
    "en": "Expanding tours and visitor routes.",
    "ar": "توسيع الجولات والمسارات السياحية."
  },
  "m371": {
    "en": "Offering new investment opportunities.",
    "ar": "طرح فرص استثمارية جديدة."
  },
  "m372": {
    "en": "Connecting the area with hotels and tourism companies.",
    "ar": "ربط المنطقة بالفنادق وشركات السياحة."
  },
  "m373": {
    "en": "Creating a unified events calendar.",
    "ar": "إنشاء تقويم فعاليات موحد."
  },
  "m374": {
    "en": "Expanding the digital platform to cover the entire area.",
    "ar": "توسيع المنصة الرقمية لتشمل المنطقة بأكملها."
  },
  "m375": {
    "en": "Preliminary expansion diagram",
    "ar": "مخطط توسع مبدئي"
  },
  "m376": {
    "en": "The project street",
    "ar": "الشارع موضوع المشروع"
  },
  "m377": {
    "en": "Adjacent heritage side streets",
    "ar": "فروع تراثية مجاورة"
  },
  "m378": {
    "en": "Cultural routes",
    "ar": "مسارات ثقافية"
  },
  "m379": {
    "en": "Digital services",
    "ar": "خدمات رقمية"
  },
  "m380": {
    "en": "Hotels and Corniche",
    "ar": "فنادق وكورنيش"
  },
  "m381": {
    "en": "[Expansion phase boundaries and locations will be added after the field survey]",
    "ar": "[تضاف حدود ومواقع مراحل التوسع بعد المسح الميداني]"
  },
  "m382": {
    "en": "Open {v0}",
    "ar": "فتح {v0}"
  },
  "m383": {
    "en": "Property Colour Legend",
    "ar": "توضيح ألوان العقارات"
  },
  "m384": {
    "en": "Properties targeted for restoration and rehabilitation",
    "ar": "عقارات مستهدفة للترميم وإعادة التأهيل"
  },
  "m385": {
    "en": "Green identifies properties requiring architectural intervention and restoration within the project area.",
    "ar": "يمثل اللون الأخضر العقارات التي تحتاج إلى معالجة عمرانية وترميم ضمن نطاق المشروع."
  },
  "m386": {
    "en": "Existing properties requiring no restoration",
    "ar": "عقارات قائمة لا تحتاج إلى ترميم"
  },
  "m387": {
    "en": "Blue identifies established projects with current owners, including the hotel, the House of Antiques Museum and Asia Gate Insurance.",
    "ar": "يمثل اللون الأزرق مشاريع قائمة ومالكوها حاليون، وتشمل الفندق، متحف بيت التحفيات، وبوابة آسيا للتأمين."
  },
  "m388": {
    "en": "Deteriorated properties requiring demolition",
    "ar": "عقارات متهالكة تحتاج إلى إزالة"
  },
  "m389": {
    "en": "Red identifies properties with severely deteriorated structural conditions requiring demolition within the area improvement plan.",
    "ar": "يمثل اللون الأحمر العقارات ذات الحالة الإنشائية المتدهورة والتي تتطلب الهدم ضمن خطة معالجة النطاق."
  },
  "m390": {
    "en": "Image controls",
    "ar": "التحكم بالصورة"
  },
  "m391": {
    "en": "Zoom in",
    "ar": "تكبير"
  },
  "m392": {
    "en": "Zoom out",
    "ar": "تصغير"
  },
  "m393": {
    "en": "Reset",
    "ar": "إعادة الضبط"
  },
  "m394": {
    "en": "Close",
    "ar": "إغلاق"
  },
  "m395": {
    "en": "Abaad Aliraq",
    "ar": "أبعاد العراق"
  },
  "m396": {
    "en": "Abaad Aliraq logo",
    "ar": "شعار أبعاد العراق"
  },
  "m397": {
    "en": "Presentation designed by Abaad Aliraq",
    "ar": "تم تصميم العرض التقديمي بواسطة ابعاد العراق"
  },
  "m398": {
    "en": "Contact",
    "ar": "للتواصل"
  },
  "m399": {
    "en": "After",
    "ar": "بعد"
  },
  "m400": {
    "en": "Before",
    "ar": "قبل"
  },
  "m401": {
    "en": "Vision image required",
    "ar": "صورة الرؤية مطلوبة"
  },
  "m402": {
    "en": "Close expanded view",
    "ar": "إغلاق العرض الموسع"
  },
  "m403": {
    "en": "Previous image",
    "ar": "الصورة السابقة"
  },
  "m404": {
    "en": "Before-and-after comparison",
    "ar": "مقارنة قبل وبعد"
  },
  "m405": {
    "en": "Hide comparison",
    "ar": "إخفاء المقارنة"
  },
  "m406": {
    "en": "Next image",
    "ar": "الصورة التالية"
  },
  "m407": {
    "en": "Abu Nawas Heritage Revitalization Project presentation",
    "ar": "عرض مشروع تأهيل واستثمار الشارع التراثي في أبو نؤاس"
  },
  "m408": {
    "en": "Presentation controls",
    "ar": "التحكم بالعرض"
  },
  "m409": {
    "en": "Previous slide",
    "ar": "الشريحة السابقة"
  },
  "m410": {
    "en": "Next slide",
    "ar": "الشريحة التالية"
  },
  "m411": {
    "en": "Fullscreen mode",
    "ar": "وضع ملء الشاشة"
  },
  "m412": {
    "en": "Slide index",
    "ar": "فهرس الشرائح"
  },
  "m413": {
    "en": "Go to {v0}",
    "ar": "اذهب إلى {v0}"
  },
  "m414": {
    "en": "Go to the next slide",
    "ar": "انتقل إلى الشريحة التالية"
  },
  "m415": {
    "en": "Conservative scenario",
    "ar": "سيناريو متحفظ"
  },
  "m416": {
    "en": "Balanced scenario",
    "ar": "سيناريو متوازن"
  },
  "m417": {
    "en": "High-growth scenario",
    "ar": "سيناريو نمو مرتفع"
  },
  "m418": {
    "en": "Street entrance",
    "ar": "مدخل الشارع"
  },
  "m419": {
    "en": "Facade improvements, circulation management and lighting",
    "ar": "معالجة الواجهة وتنظيم الحركة والإنارة"
  },
  "m420": {
    "en": "Connecting route",
    "ar": "محور الربط"
  },
  "m421": {
    "en": "Coordinating wayfinding and circulation between Abu Nawas and Al-Saadoon",
    "ar": "تنظيم الإرشاد وربط الحركة بين أبو نؤاس والسعدون"
  },
  "m422": {
    "en": "Removing encroachments",
    "ar": "إزالة التجاوزات"
  },
  "m423": {
    "en": "Improving facades and pedestrian routes while preserving the street’s identity",
    "ar": "تحسين الواجهات ومسار المشاة دون فقدان هوية الشارع"
  },
  "m424": {
    "en": "House facades",
    "ar": "واجهات البيوت"
  },
  "m425": {
    "en": "Restoring brickwork and architectural details with warm lighting",
    "ar": "ترميم الطابوق والتفاصيل المعمارية والإنارة الدافئة"
  },
  "m426": {
    "en": "Utility networks",
    "ar": "شبكات الخدمات"
  },
  "m427": {
    "en": "Organizing electricity and telecommunications and removing visual clutter",
    "ar": "تنظيم الكهرباء والاتصالات وإزالة التشابكات البصرية"
  },
  "m428": {
    "en": "Pavements and paving",
    "ar": "الأرصفة والتبليط"
  },
  "m429": {
    "en": "Coordinated paving and limited street furniture suited to the street’s width",
    "ar": "تبليط متناسق وأثاث حضري محدود يناسب عرض الشارع"
  },
  "m430": {
    "en": "Signage and identity",
    "ar": "اللوحات والهوية"
  },
  "m431": {
    "en": "Unified, unobtrusive shop signs with suitable planting",
    "ar": "لوحات محال موحدة وغير مشوهة مع تشجير مناسب"
  },
  "m432": {
    "en": "Daily activity",
    "ar": "الحركة اليومية"
  },
  "m433": {
    "en": "Visitors and natural, uncrowded movement while preserving Baghdadi proportions",
    "ar": "زوار وحركة طبيعية غير مزدحمة مع الحفاظ على النسب البغدادية"
  },
  "m434": {
    "en": "Street entrance from Abu Nawas",
    "ar": "مدخل الشارع من جهة أبو نؤاس"
  },
  "m435": {
    "en": "Documenting the street entrance and its relationship to circulation routes.",
    "ar": "توثيق لمدخل الشارع وعلاقته بمحور الحركة."
  },
  "m436": {
    "en": "Tangled electricity and telecommunications networks",
    "ar": "تشابك شبكات الكهرباء والاتصالات"
  },
  "m437": {
    "en": "A portrait photograph showing dense wiring and the need to organize utility networks.",
    "ar": "صورة طولية تظهر كثافة الأسلاك والحاجة إلى تنظيم الشبكات."
  },
  "m438": {
    "en": "Encroachments on circulation routes",
    "ar": "التجاوزات على مسار الحركة"
  },
  "m439": {
    "en": "The passage before removing encroachments and improving pedestrian movement.",
    "ar": "حالة الممر قبل إزالة التجاوزات وتحسين حركة المشاة."
  },
  "m440": {
    "en": "Condition of heritage facades",
    "ar": "حالة الواجهات التراثية"
  },
  "m441": {
    "en": "A portrait view showing house details and restoration needs.",
    "ar": "واجهة طولية توضح تفاصيل البيوت وحاجتها إلى ترميم."
  },
  "m442": {
    "en": "Houses of architectural value",
    "ar": "البيوت ذات القيمة المعمارية"
  },
  "m443": {
    "en": "Documenting a group of buildings with potential for rehabilitation and operation.",
    "ar": "توثيق لكتلة عمرانية يمكن إعادة تأهيلها وتشغيلها."
  },
  "m444": {
    "en": "Condition of pavements and paving",
    "ar": "حالة الأرصفة والتبليط"
  },
  "m445": {
    "en": "A landscape photograph showing the need to improve ground surfaces and circulation routes.",
    "ar": "صورة عرضية تظهر الحاجة إلى معالجة الأرضيات ومسارات الحركة."
  },
  "m446": {
    "en": "Connection to the Corniche",
    "ar": "الاتصال مع الكورنيش"
  },
  "m447": {
    "en": "A view showing the potential to connect the street with surrounding visitor routes.",
    "ar": "زاوية توضح قابلية ربط الشارع بمسار الزيارة المحيط."
  },
  "m448": {
    "en": "Surroundings of the House of Antiques Museum",
    "ar": "محيط متحف بيت التحفيات"
  },
  "m449": {
    "en": "Documenting the built environment and the established attraction within the street.",
    "ar": "توثيق للمحيط العمراني ونقطة الجذب القائمة داخل الشارع."
  },
  "m450": {
    "en": "Street entrance after circulation improvements",
    "ar": "مدخل الشارع بعد تنظيم الحركة"
  },
  "m451": {
    "en": "An initial vision for facade treatment, lighting and the entrance route.",
    "ar": "رؤية أولية لمعالجة الواجهة والإنارة ومسار الدخول."
  },
  "m452": {
    "en": "Addressing encroachments and service infrastructure",
    "ar": "معالجة التجاوزات والبنية الخدمية"
  },
  "m453": {
    "en": "An initial concept for organizing wiring, facades and pedestrian routes.",
    "ar": "تصور أولي لتنظيم الأسلاك والواجهات ومسار المشاة."
  },
  "m454": {
    "en": "Restoring heritage facades",
    "ar": "ترميم الواجهات التراثية"
  },
  "m455": {
    "en": "A view along the street preserving architectural proportions and adding warm lighting.",
    "ar": "رؤية طولية تحفظ النسب المعمارية وتضيف إنارة دافئة."
  },
  "m456": {
    "en": "A Unified Street Identity",
    "ar": "هوية موحدة للشارع"
  },
  "m457": {
    "en": "An initial concept for signage, lighting and planting while preserving Baghdadi identity.",
    "ar": "تصور أولي للوحات والإنارة والتشجير دون فقدان الهوية البغدادية."
  },
  "m458": {
    "en": "Pavement and Paving Vision",
    "ar": "رؤية الأرصفة والتبليط"
  },
  "m459": {
    "en": "A vision image from the same viewpoint will be added once prepared.",
    "ar": "تضاف صورة الرؤية من الزاوية نفسها بعد إعدادها."
  },
  "m460": {
    "en": "Vision for Houses of Architectural Value",
    "ar": "رؤية البيوت ذات القيمة المعمارية"
  },
  "m461": {
    "en": "Vision for the Connection to the Corniche",
    "ar": "رؤية الاتصال مع الكورنيش"
  },
  "m462": {
    "en": "Vision for the House of Antiques Museum Surroundings",
    "ar": "رؤية محيط متحف بيت التحفيات"
  },
  "contactCall": {
    "en": "Call",
    "ar": "اتصال"
  },
  "contactWebsite": {
    "en": "Website",
    "ar": "الموقع الإلكتروني"
  },
  "contactWhatsApp": {
    "en": "WhatsApp",
    "ar": "واتساب"
  },
  "contactEmail": {
    "en": "Email",
    "ar": "البريد الإلكتروني"
  },
  "switchLanguage": {
    "en": "Switch to Arabic",
    "ar": "التبديل إلى الإنكليزية"
  }
} as const;

export const sourceKeys: Record<string, keyof typeof messages> = {
  "مشروع تأهيل واستثمار الشارع التراثي في أبو نؤاس": "m001",
  "رؤية متكاملة للحفاظ العمراني والتنمية السياحية والاستثمارية": "m002",
  "بغداد — أبو نؤاس": "m003",
  "موقع المشروع ومحاور الوصول": "m004",
  "خريطة توضيحية لموقع المشروع وعلاقته بمحاور الحركة والوصول المحيطة.": "m005",
  "02 — الفرصة": "m006",
  "موقع استراتيجي وقيمة تراثية غير مستثمرة": "m007",
  "يربط الشارع بين أبو نؤاس والسعدون، ويقع بالقرب من الكورنيش الجديد ومجموعة من الفنادق، ما يمنحه مقومات حقيقية للتحول إلى وجهة تراثية وسياحية نشطة. إلا أن الإهمال البصري والخدمي يحجب حالياً قيمته العمرانية والاستثمارية.": "m008",
  "بيتاً ضمن نطاق المشروع": "m009",
  "100–250 م²": "m010",
  "المساحة التقديرية للبيت الواحد": "m011",
  "موقع محوري": "m012",
  "يربط أبو نؤاس بالسعدون": "m013",
  "جذب سياحي قائم": "m014",
  "متحف بيت التحفيات": "m015",
  "فرصة استثمارية": "m016",
  "أصول تراثية قابلة لإعادة التوظيف": "m017",
  "03 — الموقع الاستراتيجي": "m018",
  "موقع استراتيجي بين أبو نؤاس والسعدون": "m019",
  "موقع المشروع ضمن النسيج السياحي لوسط بغداد": "m020",
  "يقع المشروع ضمن محور رابط بين شارع أبو نؤاس وشارع السعدون، مقابل بوابة الدخول والخروج من الكورنيش الجديد، وعلى مقربة من مجموعة من الفنادق ونقاط الجذب السياحي القائمة، مما يمنحه قابلية حقيقية للتحول إلى وجهة تراثية وسياحية نشطة.": "m021",
  "الموقع الاستراتيجي للمشروع": "m022",
  "محور رابط بين شارع أبو نؤاس وشارع السعدون": "m023",
  "04 — حالة الشارع الحالية": "m024",
  "حالة الشارع الحالية": "m025",
  "توثيق بصري لحالة الشارع والبيوت التراثية والتجاوزات والأسلاك والبنية الخدمية قبل بدء أعمال التأهيل.": "m026",
  "العقارات والمساحات المستهدفة ضمن نطاق المشروع": "m027",
  "خريطة توضيحية للعقارات والمساحات المستهدفة ضمن نطاق المشروع.": "m028",
  "05 — الرؤية المبدئية بعد التأهيل": "m029",
  "الرؤية المبدئية بعد التأهيل": "m030",
  "تصور أولي لإمكانات الشارع بعد معالجة التجاوزات والبنية التحتية وترميم الواجهات وإضافة الإنارة والتشجير والهوية الموحدة.": "m031",
  "06 — الواقع الحالي": "m032",
  "قيمة معمارية محاصرة بالفوضى البصرية": "m033",
  "أسلاك متشابكة ومكشوفة.": "m034",
  "تجاوزات تشوه الواجهات ومسار الحركة.": "m035",
  "أرصفة وتبليط غير متجانسين.": "m036",
  "واجهات بلا معالجة موحدة.": "m037",
  "ضعف الإنارة والتشجير.": "m038",
  "غياب الإرشاد السياحي والهوية المكانية.": "m039",
  "07 — الأصل القابل للبناء": "m040",
  "المشروع لا يبدأ من الصفر": "m041",
  "يمتلك الشارع مباني تراثية قائمة، وموقعاً متصلاً بمحاور الضيافة والسياحة، إضافة إلى وجود متحف بيت التحفيات داخل الشارع، وهو متحف ومتجر متخصص بالأنتيك والمقتنيات التراثية، ويستقطب منذ عقود السياح والفنانين والمهتمين بالفن والتراث.": "m042",
  "08 — الرؤية المقترحة": "m043",
  "من شارع مهمل إلى منطقة تراثية منتجة": "m044",
  "الحفظ": "m045",
  "ترميم البيوت والعناصر المعمارية الأصلية.": "m046",
  "التشغيل": "m047",
  "تحويل المباني إلى مشاريع ثقافية وسياحية وضيافة.": "m048",
  "العائد": "m049",
  "خلق إيرادات مباشرة وغير مباشرة وفرص عمل ونشاط اقتصادي محلي.": "m050",
  "09 — نطاق التأهيل الحضري": "m051",
  "تدخل حضري منظم قبل التشغيل التجاري": "m052",
  "رفع التجاوزات وتنظيم الواجهات.": "m053",
  "معالجة ونقل شبكات الكهرباء والاتصالات بطريقة نظامية وآمنة.": "m054",
  "تنظيف الشارع وإدارة المخلفات.": "m055",
  "إعادة تبليط الشارع والأرصفة.": "m056",
  "ترميم وصبغ الواجهات وفق دليل موحد.": "m057",
  "إنارة معمارية، تشجير، أثاث حضري، ولوحات ثنائية اللغة.": "m058",
  "تنظيم حركة المركبات ومواقف الخدمة وأنظمة السلامة.": "m059",
  "تنفذ أعمال الترميم بعد توثيق معماري وإنشائي متخصص.": "m060",
  "10 — إعادة توظيف البيوت الستة عشر": "m061",
  "مزيج أنشطة يصنع وجهة لا نسخة مكررة": "m062",
  "فندق بوتيك تراثي": "m063",
  "بيوت ضيافة بغدادية": "m064",
  "مطعم عراقي معاصر": "m065",
  "مقهى ثقافي": "m066",
  "معرض فنون": "m067",
  "متحف للذاكرة البغدادية": "m068",
  "مركز للحرف التقليدية": "m069",
  "متاجر أنتيك ومقتنيات": "m070",
  "استوديوهات ومراسم للفنانين": "m071",
  "مساحة عروض موسيقية وأمسيات": "m072",
  "مكتبة ومتجر كتب وصور تاريخية": "m073",
  "مركز تجارب طبخ عراقي": "m074",
  "بيت للأزياء والحرف العراقية": "m075",
  "مركز للزوار والمعلومات السياحية": "m076",
  "مساحة للمعارض المؤقتة": "m077",
  "حاضنة للصناعات الثقافية": "m078",
  "التخصيص النهائي لكل عقار يعتمد على حالته الإنشائية ومساحته والجدوى الاستثمارية ومنع تكرار الأنشطة.": "m079",
  "11 — تمكين المرأة": "m080",
  "المرأة شريك في تشغيل الاقتصاد التراثي": "m081",
  "برنامج اقتصادي لدعم مشاركة المرأة في الصناعات الثقافية والإبداعية": "m082",
  "يخصص المشروع مساراً لتمكين المرأة اقتصادياً من خلال إشراك المشاريع النسائية والحرفيات والفنانات والمرشدات السياحيات في تشغيل الأنشطة الثقافية والتجارية، بالتعاون مع مؤسسات متخصصة أو جهة راعية، وبمؤشرات واضحة لفرص العمل والمبيعات واستدامة المشاريع.": "m083",
  "12 — نموذج الإيرادات": "m084",
  "كيف يحقق المشروع إيرادات مستدامة؟": "m085",
  "تحويل الأصول التراثية من مبانٍ مهملة إلى منظومة سياحية واستثمارية منتجة": "m086",
  "13 — محاكاة مالية": "m087",
  "محاكاة الإيرادات والعائد المالي": "m088",
  "أداة أولية لقياس السيناريوهات قبل استكمال التقييم العقاري ودراسة الجدوى التفصيلية": "m089",
  "14 — قابلية التوسع": "m090",
  "من مشروع تجريبي إلى منطقة تراثية متكاملة": "m091",
  "يمثل الشارع المرحلة الأولى لنموذج حضري واستثماري قابل للتوسع نحو الفروع المحيطة، التي تضم بدورها عدداً من البيوت التراثية والمباني المهملة. ويتيح نجاح المرحلة الأولى إنشاء شبكة مترابطة من المسارات الثقافية والسياحية بدلاً من الاكتفاء بتأهيل شارع منفرد.": "m092",
  "15 — نموذج التملك والاستثمار": "m093",
  "نموذج هجين يقلل كلفة البداية ويسرّع التشغيل": "m094",
  "شراء أو استملاك": "m095",
  "للعقارات ذات الأولوية عندما تكون الجدوى واضحة.": "m096",
  "إيجار طويل الأمد": "m097",
  "مع التزام المستثمر بالترميم والتشغيل.": "m098",
  "شراكة إيرادات": "m099",
  "تقاسم العائد بين المالك والمشغل بحسب النشاط.": "m100",
  "16 — العائد المالي": "m101",
  "مصادر إيراد متعددة دون أرقام افتراضية": "m102",
  "بدلات إيجار العقارات بعد الترميم": "m103",
  "رسوم الانتفاع والاستثمار": "m104",
  "نسبة من إيرادات بعض المشروعات": "m105",
  "تذاكر المتاحف والمعارض والتجارب": "m106",
  "رسوم الفعاليات والأسواق الموسمية": "m107",
  "الرعايات وحقوق تسمية الفعاليات": "m108",
  "مواقف السيارات وخدمات التنقل": "m109",
  "ترخيص التصوير والإنتاج الإعلامي": "m110",
  "متجر رقمي موحد وجولات سياحية مدفوعة": "m111",
  "ارتفاع القيمة الاقتصادية والنشاط السياحي": "m112",
  "[تدرج كلفة التملك والترميم والتشغيل والإيرادات بعد استكمال التقييم المالي والعقاري]": "m113",
  "17 — الخدمات الرقمية": "m114",
  "طبقة رقمية تحول الشارع إلى تجربة متصلة": "m115",
  "موقع وتطبيق Web App للشارع مع خريطة تفاعلية.": "m116",
  "جولة افتراضية ثلاثية الأبعاد قبل وبعد الترميم.": "m117",
  "تذاكر وحجوزات موحدة للفعاليات والتجارب.": "m118",
  "رموز QR ودليل صوتي بالعربية والإنجليزية.": "m119",
  "واقع معزز، متجر إلكتروني، برنامج ولاء، وجواز رقمي.": "m120",
  "لوحة تحكم للزوار والحجوزات والإيرادات، مع أرشيف رقمي للمخططات والصور والوثائق.": "m121",
  "الخدمات الرقمية وسيلة للتشغيل والقياس وتحقيق الإيرادات، وليست إضافات دعائية.": "m122",
  "18 — رحلة الزائر": "m123",
  "رحلة قصيرة وواضحة من الاكتشاف إلى العودة": "m124",
  "اكتشاف المشروع رقمياً": "m125",
  "الوصول من الكورنيش أو الفندق": "m126",
  "الدخول عبر بوابة الشارع": "m127",
  "استكشاف البيوت والأنشطة": "m128",
  "الحجز أو الشراء": "m129",
  "حضور فعالية أو تجربة": "m130",
  "مشاركة الزيارة والعودة مجدداً": "m131",
  "19 — خطة التنفيذ": "m132",
  "برنامج تطوير مرحلي قابل للتكيّف مع نتائج التقييم": "m133",
  "تتحدد وتيرة التنفيذ وفق نتائج المسح الإنشائي والعقاري، وإجراءات التملك أو التعاقد، وأولويات الترميم، وجاهزية البنية التحتية، وطرح الفرص الاستثمارية.": "m134",
  "01 — التوثيق والتقييم": "m135",
  "قراءة دقيقة قبل التدخل": "m136",
  "المسح العقاري والإنشائي.": "m137",
  "توثيق البيوت والعناصر المعمارية.": "m138",
  "تحديد الأولويات والمخاطر.": "m139",
  "02 — معالجة البنية التحتية": "m140",
  "تنظيم الشبكات والخدمات": "m141",
  "إزالة التجاوزات الخطرة.": "m142",
  "معالجة الأسلاك والشبكات.": "m143",
  "تحسين التبليط والإنارة والتشجير.": "m144",
  "03 — الترميم وإعادة التأهيل": "m145",
  "حفظ القيمة العمرانية": "m146",
  "ترميم العقارات ذات الأولوية.": "m147",
  "توحيد الواجهات والإرشاد.": "m148",
  "تجهيز المباني للاستخدام المناسب.": "m149",
  "04 — الطرح والتشغيل الاستثماري": "m150",
  "تحويل الأصول إلى نشاط": "m151",
  "طرح فرص الاستثمار.": "m152",
  "تشغيل الأنشطة الأولى.": "m153",
  "قياس الطلب وتجربة الزائر.": "m154",
  "05 — التوسع والتطوير المستمر": "m155",
  "تحسين الأداء وتوسيع الأثر": "m156",
  "توسيع الأنشطة الناجحة.": "m157",
  "ربط المشروع بالفنادق والسياحة.": "m158",
  "تحسين نموذج التشغيل وفق المؤشرات.": "m159",
  "20 — البداية الذكية": "m160",
  "لا ننتظر اكتمال 16 بيتاً حتى يبدأ المشروع": "m161",
  "مدخل الشارع من جهة أبو نؤاس.": "m162",
  "متحف بيت التحفيات كنقطة جذب قائمة.": "m163",
  "بيتان أو ثلاثة بيوت ذات أولوية.": "m164",
  "تنظيف وتنظيم وإنارة جزء واضح من الشارع.": "m165",
  "فعالية افتتاحية وجولة افتراضية توثق التحول.": "m166",
  "طرح أول الفرص الاستثمارية.": "m167",
  "الهدف: نتيجة ملموسة وسريعة، اختبار التشغيل، وبناء ثقة المستثمرين قبل التوسع.": "m168",
  "21 — الحملة التسويقية": "m169",
  "الشارع التراثي في أبو نؤاس — بغداد التي تُعاش": "m170",
  "بغداد تُفتح من بابها القديم": "m171",
  "قبل الافتتاح": "m172",
  "قصص البيوت، قبل وبعد، يوميات الترميم، ولقاءات مع سكان وفنانين وحرفيين.": "m173",
  "الإطلاق": "m174",
  "أسبوع ثقافي وفني، سوق للحرف والأنتيك، جولات مرشدة، وتعاون مع الفنادق.": "m175",
  "بعد الافتتاح": "m176",
  "تقويم سنوي، ليالي متاحف، أسواق موسمية، باقات زيارة وحملات موجهة.": "m177",
  "22 — مؤشرات النجاح": "m178",
  "مؤشرات قابلة للقياس منذ اليوم الأول": "m179",
  "عدد البيوت المرممة": "m180",
  "نسبة الإشغال الاستثماري": "m181",
  "عدد الزوار": "m182",
  "متوسط إنفاق الزائر": "m183",
  "الإيرادات المباشرة": "m184",
  "عدد الفعاليات": "m185",
  "فرص العمل المستحدثة": "m186",
  "مشاركة المشاريع والحرف المحلية": "m187",
  "رضا الزوار": "m188",
  "مستوى الحفاظ على المباني": "m189",
  "الوصول الرقمي والحجوزات": "m190",
  "تكرار الزيارة": "m191",
  "23 — الخاتمة": "m192",
  "إحياء الشارع استثمار في ذاكرة بغداد واقتصادها السياحي": "m193",
  "يمتلك الشارع التراثي في أبو نؤاس عناصر النجاح الأساسية: الموقع، العمارة، التاريخ، الفنادق، الكورنيش، ونقطة جذب قائمة. المطلوب هو جمع هذه العناصر ضمن مشروع واحد قابل للتنفيذ والقياس والاستثمار.": "m194",
  "من 16 بيتاً… تبدأ وجهة جديدة لبغداد": "m195",
  "تم إعداد هذا العرض التقديمي بواسطة مكتب أبعاد العراق للحلول البرمجية": "m196",
  "زيارة الموقع الإلكتروني لمتحف بيت التحفيات": "m197",
  "01 — محور رابط": "m198",
  "محور رابط": "m199",
  "يربط شارع أبو نؤاس بشارع السعدون ويوفر اتصالاً مباشراً بين واجهة النهر ومركز المدينة.": "m200",
  "02 — بوابة الكورنيش": "m201",
  "بوابة الكورنيش": "m202",
  "يقع مدخل الشارع مقابل بوابة الدخول والخروج من مشروع الكورنيش الجديد.": "m203",
  "03 — محيط فندقي": "m204",
  "محيط فندقي": "m205",
  "يقع فندق عند ركن مدخل الشارع، إضافة إلى قربه من فندق بغداد وعدة فنادق عاملة وأخرى قيد الإنشاء.": "m206",
  "04 — نقطة جذب قائمة": "m207",
  "نقطة جذب قائمة": "m208",
  "يضم الشارع متحف بيت التحفيات، وهو متحف ومتجر أنتيك يستقطب السياح والفنانين والمهتمين بالفن والتراث منذ عقود.": "m209",
  "05 — قابلية الحركة سيراً": "m210",
  "قابلية الحركة سيراً": "m211",
  "يسمح موقع الشارع بوصول نزلاء الفنادق وزوار الكورنيش إليه سيراً دون الحاجة إلى مسار نقل منفصل.": "m212",
  "06 — فرصة للربط السياحي": "m213",
  "فرصة للربط السياحي": "m214",
  "يمكن دمج الشارع ضمن مسارات زيارة تربط الكورنيش والفنادق والمتحف والمشروعات الثقافية المستقبلية.": "m215",
  "فتح الموقع على خرائط Google": "m216",
  "الحرف والصناعات الإبداعية": "m217",
  "دعم الحرفيات والمشاريع النسائية المتخصصة بالأزياء التراثية، التطريز، الفنون، التصميم، المنتجات اليدوية والمقتنيات الثقافية.": "m218",
  "الضيافة والطعام": "m219",
  "إتاحة فرص تشغيل واستثمار لمشاريع نسائية في الطعام العراقي، الضيافة، المقاهي الثقافية وتجارب الطبخ.": "m220",
  "الإرشاد والتجارب السياحية": "m221",
  "تدريب مرشدات سياحيات وإشراكهن في إدارة الجولات، التجارب الثقافية والفعاليات.": "m222",
  "التسويق والتجارة الرقمية": "m223",
  "تدريب المشاركات على إدارة المتاجر الإلكترونية، التصوير، التسويق الرقمي وبيع المنتجات داخل المنصة الموحدة للمشروع.": "m224",
  "الفنون والفعاليات": "m225",
  "إشراك الفنانات والمصممات وخريجات كليات الفنون في المعارض، الورش، التوثيق والبرامج الثقافية.": "m226",
  "فرص التشغيل والتوريد": "m227",
  "منح المشاريع النسائية المؤهلة فرصة عادلة للمشاركة في عقود التشغيل والتوريد والخدمات.": "m228",
  "عدد المشاريع النسائية المشاركة.": "m229",
  "عدد فرص العمل المستحدثة.": "m230",
  "قيمة المبيعات المحققة.": "m231",
  "عدد المستفيدات من التدريب.": "m232",
  "نسبة استمرارية المشاريع.": "m233",
  "قيمة عقود التشغيل والتوريد.": "m234",
  "إيجارات البيوت والمرافق بعد التأهيل.": "m235",
  "رسوم الانتفاع والاستثمار.": "m236",
  "نسبة مشاركة من إيرادات بعض المشروعات.": "m237",
  "تذاكر المتاحف والمعارض والتجارب.": "m238",
  "رسوم الجولات السياحية.": "m239",
  "رسوم الفعاليات والأسواق الموسمية.": "m240",
  "الرعايات التجارية والثقافية.": "m241",
  "تراخيص التصوير والإنتاج الإعلامي.": "m242",
  "إيرادات المتجر الإلكتروني الموحد.": "m243",
  "خدمات مواقف السيارات والنقل عند اعتمادها.": "m244",
  "رفع القيمة الاقتصادية للعقارات المحيطة.": "m245",
  "زيادة إنفاق السياح ونزلاء الفنادق في المنطقة.": "m246",
  "تنشيط المطاعم والمتاجر والخدمات المجاورة.": "m247",
  "خلق فرص عمل مباشرة وغير مباشرة.": "m248",
  "جذب استثمارات جديدة إلى المنطقة.": "m249",
  "زيادة مدة بقاء الزائر داخل مركز بغداد.": "m250",
  "دعم الصناعات الثقافية والحرفية المحلية.": "m251",
  "عدد البيوت الداخلة في المرحلة": "m252",
  "بيت": "m253",
  "عدد البيوت التي تدخل ضمن كلفة الشراء والترميم في السيناريو.": "m254",
  "متوسط مساحة البيت": "m255",
  "م²": "m256",
  "متوسط افتراضي بين 100 و250 م² إلى حين تثبيت مساحة كل بيت.": "m257",
  "سعر شراء المتر": "m258",
  "دولار/م²": "m259",
  "سعر تقديري للمتر لأغراض المحاكاة فقط، وليس تقييماً عقارياً.": "m260",
  "كلفة الترميم لكل متر مربع": "m261",
  "كلفة افتراضية تشمل أعمال التأهيل المعماري والخدمات الأساسية.": "m262",
  "عدد البيوت المطروحة للاستثمار": "m263",
  "عدد البيوت التي تحقق إيراد إيجار ضمن السيناريو الحالي.": "m264",
  "متوسط الإيجار الشهري لكل متر مربع": "m265",
  "متوسط افتراضي لبدل الإيجار الشهري بعد التأهيل والتشغيل.": "m266",
  "نسبة الإشغال": "m267",
  "النسبة السنوية المتوقعة لاستثمار المساحات المطروحة.": "m268",
  "عدد الزوار السنوي": "m269",
  "زائر": "m270",
  "عدد الزوار المدفوعين للتذاكر أو الجولات خلال سنة.": "m271",
  "متوسط سعر التذكرة أو الجولة": "m272",
  "دولار": "m273",
  "متوسط سعر الدخول أو الجولة الثقافية.": "m274",
  "عدد الفعاليات السنوي": "m275",
  "فعالية": "m276",
  "الفعاليات والأسواق الموسمية والورش المدرة للإيراد.": "m277",
  "متوسط إيراد الفعالية": "m278",
  "متوسط الإيراد المباشر لكل فعالية.": "m279",
  "إيرادات الرعاية السنوية": "m280",
  "رعايات ثقافية وتجارية محتملة قابلة للتعديل.": "m281",
  "إيرادات التصوير والتراخيص": "m282",
  "تصوير وإنتاج إعلامي وحقوق استخدام مرتبطة بالموقع.": "m283",
  "الإيرادات الرقمية والمتجر الإلكتروني": "m284",
  "بيع رقمي، حجوزات، متجر موحد، وتجارب إلكترونية.": "m285",
  "مبيعات المستثمرين الخاضعة للمشاركة": "m286",
  "إجمالي مبيعات مشروعات مختارة تحسب عليها نسبة مشاركة المشروع.": "m287",
  "نسبة مشاركة المشروع من مبيعات المستثمرين": "m288",
  "نسبة افتراضية من مبيعات بعض المشروعات عند اعتمادها تعاقدياً.": "m289",
  "كلفة التشغيل السنوية": "m290",
  "إدارة وتشغيل وصيانة وتسويق وخدمات سنوية.": "m291",
  "أي كلفة تأسيس مضافة": "m292",
  "تجهيزات تأسيسية أو أنظمة أو مصاريف إطلاق غير داخلة في الشراء والترميم.": "m293",
  "معدل النمو السنوي": "m294",
  "يستخدم فقط في توقع خمس سنوات، ولا توجد نسبة نمو مخفية داخل الكود.": "m295",
  "{v0} دولار": "m296",
  "فرصة للشراكة والرعاية": "m297",
  "يمكن لجهة راعية أو مؤسسة متخصصة في تمكين المرأة دعم التدريب والتجهيز وبرامج تطوير المشاريع، مقابل الظهور كشريك للبرنامج وقياس أثر الرعاية بصورة واضحة.": "m298",
  "عدادات Placeholder": "m299",
  "عدد المشاريع": "m300",
  "فرص العمل": "m301",
  "المبيعات": "m302",
  "المستفيدات": "m303",
  "قيمة Placeholder": "m304",
  "العائد الاقتصادي غير المباشر": "m305",
  "مسار تحقيق الإيرادات": "m306",
  "أصول تراثية": "m307",
  "تأهيل وتشغيل": "m308",
  "نشاط سياحي وتجاري": "m309",
  "إيرادات مباشرة": "m310",
  "إعادة استثمار وتوسع": "m311",
  "لا يعتمد المشروع على مصدر دخل واحد، بل يجمع بين الإيجار والتشغيل والتذاكر والفعاليات والرعاية والخدمات الرقمية.": "m312",
  "إيجارات": "m313",
  "تذاكر": "m314",
  "فعاليات": "m315",
  "رعايات": "m316",
  "تراخيص": "m317",
  "رقمي": "m318",
  "الصافي": "m319",
  "سيناريو": "m320",
  "السنة {v0}": "m321",
  "إجمالي الإيرادات: {v0}": "m322",
  "صافي الإيراد: {v0}": "m323",
  "الإيراد: {v0}": "m324",
  "الصافي: {v0}": "m325",
  "إيجارات البيوت": "m326",
  "التذاكر والجولات": "m327",
  "الفعاليات": "m328",
  "الرعايات": "m329",
  "التصوير والتراخيص": "m330",
  "الإيرادات الرقمية": "m331",
  "الإجمالي": "m332",
  "القيمة العقارية التقديرية": "m333",
  "كلفة الترميم التقديرية": "m334",
  "إجمالي الاستثمار الأولي": "m335",
  "إيرادات الإيجارات السنوية": "m336",
  "إيرادات الزوار والفعاليات": "m337",
  "إجمالي الإيرادات السنوية": "m338",
  "صافي الإيراد التشغيلي": "m339",
  "فترة الاسترداد التقريبية": "m340",
  "{v0} سنة": "m341",
  "غير متاح ضمن السيناريو الحالي": "m342",
  "العائد التشغيلي السنوي": "m343",
  "الأرقام الواردة أدناه افتراضات أولية لأغراض المحاكاة، ولا تمثل تقييماً عقارياً أو دراسة جدوى نهائية.": "m344",
  "سيناريوهات المحاكاة": "m345",
  "مدخلات المحاكاة": "m346",
  "{v0} كتابة يدوية": "m347",
  "مخرجات المحاكاة": "m348",
  "نطاق القيمة العقارية الأولية": "m349",
  "الحد الأدنى النظري: 16 × 100 م² × 2,000 دولار = 3,200,000 دولار": "m350",
  "الحد الأعلى النظري: 16 × 250 م² × 2,500 دولار = 10,000,000 دولار": "m351",
  "هذا النطاق لا يمثل كلفة شراء نهائية، لأن المساحة والحالة الإنشائية والقيمة السوقية لكل بيت تحتاج إلى تقييم منفصل.": "m352",
  "توزيع الإيرادات السنوية": "m353",
  "مقارنة السيناريوهات": "m354",
  "توقع خمس سنوات": "m355",
  "طباعة النتائج": "m356",
  "مصدر الإيراد": "m357",
  "سنوي": "m358",
  "خمس سنوات": "m359",
  "النسبة من الإجمالي": "m360",
  "المرحلة الأولى": "m361",
  "تأهيل وتشغيل الشارع موضوع المشروع وقياس الأداء الفعلي.": "m362",
  "المرحلة الثانية": "m363",
  "ربط الفروع التراثية المجاورة بالهوية والإرشاد والخدمات الرقمية والفعاليات.": "m364",
  "المرحلة الثالثة": "m365",
  "إنشاء منطقة تراثية مترابطة ترتبط بأبو نؤاس والسعدون والكورنيش والفنادق المحيطة.": "m366",
  "توثيق البيوت التراثية في الفروع المجاورة.": "m367",
  "تحديد العقارات ذات الأولوية.": "m368",
  "توحيد الهوية العمرانية والإرشادية.": "m369",
  "توسيع الجولات والمسارات السياحية.": "m370",
  "طرح فرص استثمارية جديدة.": "m371",
  "ربط المنطقة بالفنادق وشركات السياحة.": "m372",
  "إنشاء تقويم فعاليات موحد.": "m373",
  "توسيع المنصة الرقمية لتشمل المنطقة بأكملها.": "m374",
  "مخطط توسع مبدئي": "m375",
  "الشارع موضوع المشروع": "m376",
  "فروع تراثية مجاورة": "m377",
  "مسارات ثقافية": "m378",
  "خدمات رقمية": "m379",
  "فنادق وكورنيش": "m380",
  "[تضاف حدود ومواقع مراحل التوسع بعد المسح الميداني]": "m381",
  "فتح {v0}": "m382",
  "توضيح ألوان العقارات": "m383",
  "عقارات مستهدفة للترميم وإعادة التأهيل": "m384",
  "يمثل اللون الأخضر العقارات التي تحتاج إلى معالجة عمرانية وترميم ضمن نطاق المشروع.": "m385",
  "عقارات قائمة لا تحتاج إلى ترميم": "m386",
  "يمثل اللون الأزرق مشاريع قائمة ومالكوها حاليون، وتشمل الفندق، متحف بيت التحفيات، وبوابة آسيا للتأمين.": "m387",
  "عقارات متهالكة تحتاج إلى إزالة": "m388",
  "يمثل اللون الأحمر العقارات ذات الحالة الإنشائية المتدهورة والتي تتطلب الهدم ضمن خطة معالجة النطاق.": "m389",
  "التحكم بالصورة": "m390",
  "تكبير": "m391",
  "تصغير": "m392",
  "إعادة الضبط": "m393",
  "إغلاق": "m394",
  "أبعاد العراق": "m395",
  "شعار أبعاد العراق": "m396",
  "تم تصميم العرض التقديمي بواسطة ابعاد العراق": "m397",
  "لتواصل": "m398",
  "بعد": "m399",
  "قبل": "m400",
  "صورة الرؤية مطلوبة": "m401",
  "إغلاق العرض الموسع": "m402",
  "الصورة السابقة": "m403",
  "مقارنة قبل وبعد": "m404",
  "إخفاء المقارنة": "m405",
  "الصورة التالية": "m406",
  "عرض مشروع تأهيل واستثمار الشارع التراثي في أبو نؤاس": "m407",
  "التحكم بالعرض": "m408",
  "الشريحة السابقة": "m409",
  "الشريحة التالية": "m410",
  "وضع ملء الشاشة": "m411",
  "فهرس الشرائح": "m412",
  "اذهب إلى {v0}": "m413",
  "انتقل إلى الشريحة التالية": "m414",
  "سيناريو متحفظ": "m415",
  "سيناريو متوازن": "m416",
  "سيناريو نمو مرتفع": "m417",
  "مدخل الشارع": "m418",
  "معالجة الواجهة وتنظيم الحركة والإنارة": "m419",
  "محور الربط": "m420",
  "تنظيم الإرشاد وربط الحركة بين أبو نؤاس والسعدون": "m421",
  "إزالة التجاوزات": "m422",
  "تحسين الواجهات ومسار المشاة دون فقدان هوية الشارع": "m423",
  "واجهات البيوت": "m424",
  "ترميم الطابوق والتفاصيل المعمارية والإنارة الدافئة": "m425",
  "شبكات الخدمات": "m426",
  "تنظيم الكهرباء والاتصالات وإزالة التشابكات البصرية": "m427",
  "الأرصفة والتبليط": "m428",
  "تبليط متناسق وأثاث حضري محدود يناسب عرض الشارع": "m429",
  "اللوحات والهوية": "m430",
  "لوحات محال موحدة وغير مشوهة مع تشجير مناسب": "m431",
  "الحركة اليومية": "m432",
  "زوار وحركة طبيعية غير مزدحمة مع الحفاظ على النسب البغدادية": "m433",
  "مدخل الشارع من جهة أبو نؤاس": "m434",
  "توثيق لمدخل الشارع وعلاقته بمحور الحركة.": "m435",
  "تشابك شبكات الكهرباء والاتصالات": "m436",
  "صورة طولية تظهر كثافة الأسلاك والحاجة إلى تنظيم الشبكات.": "m437",
  "التجاوزات على مسار الحركة": "m438",
  "حالة الممر قبل إزالة التجاوزات وتحسين حركة المشاة.": "m439",
  "حالة الواجهات التراثية": "m440",
  "واجهة طولية توضح تفاصيل البيوت وحاجتها إلى ترميم.": "m441",
  "البيوت ذات القيمة المعمارية": "m442",
  "توثيق لكتلة عمرانية يمكن إعادة تأهيلها وتشغيلها.": "m443",
  "حالة الأرصفة والتبليط": "m444",
  "صورة عرضية تظهر الحاجة إلى معالجة الأرضيات ومسارات الحركة.": "m445",
  "الاتصال مع الكورنيش": "m446",
  "زاوية توضح قابلية ربط الشارع بمسار الزيارة المحيط.": "m447",
  "محيط متحف بيت التحفيات": "m448",
  "توثيق للمحيط العمراني ونقطة الجذب القائمة داخل الشارع.": "m449",
  "مدخل الشارع بعد تنظيم الحركة": "m450",
  "رؤية أولية لمعالجة الواجهة والإنارة ومسار الدخول.": "m451",
  "معالجة التجاوزات والبنية الخدمية": "m452",
  "تصور أولي لتنظيم الأسلاك والواجهات ومسار المشاة.": "m453",
  "ترميم الواجهات التراثية": "m454",
  "رؤية طولية تحفظ النسب المعمارية وتضيف إنارة دافئة.": "m455",
  "هوية موحدة للشارع": "m456",
  "تصور أولي للوحات والإنارة والتشجير دون فقدان الهوية البغدادية.": "m457",
  "رؤية الأرصفة والتبليط": "m458",
  "تضاف صورة الرؤية من الزاوية نفسها بعد إعدادها.": "m459",
  "رؤية البيوت ذات القيمة المعمارية": "m460",
  "رؤية الاتصال مع الكورنيش": "m461",
  "رؤية محيط متحف بيت التحفيات": "m462"
};
