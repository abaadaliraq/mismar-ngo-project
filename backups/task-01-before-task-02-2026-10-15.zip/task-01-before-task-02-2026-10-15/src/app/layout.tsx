import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ABU NAWAS — HERITAGE REVITALIZATION PROJECT",
  description:
    "Safeguarding, Restoration & Adaptive Reuse of Historic Houses in Baghdad",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
